(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__5cefa0c0._.css",
  "static/chunks/97880_@tanstack_query-devtools_build_3c60d411._.js",
  "static/chunks/node_modules__pnpm_0e76feac._.js",
  "static/chunks/apps_web_src_95f759ac._.js"
],
    source: "dynamic"
});
