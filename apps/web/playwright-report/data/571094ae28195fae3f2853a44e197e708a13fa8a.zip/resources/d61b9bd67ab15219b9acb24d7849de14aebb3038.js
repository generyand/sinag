(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_dace21a4._.js",
  "static/chunks/a927f_next_dist_compiled_41da72f9._.js",
  "static/chunks/a927f_next_dist_client_02d16c6f._.js",
  "static/chunks/a927f_next_dist_419665f6._.js",
  "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js"
],
    source: "entry"
});
