(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/apps_web_src_lib_toast_ts_067ecc7e._.js",
  "static/chunks/_6a6d62c2._.js",
  "static/chunks/node_modules__pnpm_7bf3013b._.js"
],
    source: "dynamic"
});
