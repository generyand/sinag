(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/apps/web/src/components/ui/button.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "Button": (()=>Button),
    "buttonVariants": (()=>buttonVariants)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.3_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$slot$40$1$2e$2$2e$4_$40$types$2b$react$40$19$2e$1$2e$8_react$40$19$2e$1$2e$0$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-slot@1.2.4_@types+react@19.1.8_react@19.1.0/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$class$2d$variance$2d$authority$40$0$2e$7$2e$1$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/class-variance-authority@0.7.1/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$class$2d$variance$2d$authority$40$0$2e$7$2e$1$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", {
    variants: {
        variant: {
            default: "bg-primary text-primary-foreground shadow-xs hover:bg-primary/90",
            destructive: "bg-destructive text-white shadow-xs hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
            outline: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
            secondary: "bg-secondary text-secondary-foreground shadow-xs hover:bg-secondary/80",
            ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
            link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button({ className, variant, size, asChild = false, ...props }) {
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$slot$40$1$2e$2$2e$4_$40$types$2b$react$40$19$2e$1$2e$8_react$40$19$2e$1$2e$0$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : "button";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        "data-slot": "button",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    }, void 0, false, {
        fileName: "[project]/apps/web/src/components/ui/button.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
}
_c = Button;
;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/apps/web/src/components/ui/input.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "Input": (()=>Input),
    "inputVariants": (()=>inputVariants)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.3_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$class$2d$variance$2d$authority$40$0$2e$7$2e$1$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/class-variance-authority@0.7.1/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
// Input variants for shape and size, using theme tokens from @styling.mdc and @globals.css
const inputVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$class$2d$variance$2d$authority$40$0$2e$7$2e$1$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("file:text-foreground placeholder:text-muted selection:bg-primary selection:text-primary-foreground bg-input border border-border flex h-9 w-full min-w-0 px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", {
    variants: {
        shape: {
            boxy: "rounded-sm",
            rounded: "rounded-md",
            pill: "rounded-full"
        },
        size: {
            sm: "h-8 text-sm",
            md: "h-9 text-base",
            lg: "h-11 text-lg"
        }
    },
    defaultVariants: {
        shape: "boxy",
        size: "md"
    }
});
function Input({ className, shape, size, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        "data-slot": "input",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(inputVariants({
            shape,
            size
        }), // Focus and error states as before
        "focus-visible:border-[var(--focus)] focus-visible:ring-2 focus-visible:ring-[var(--ring)] focus-visible:ring-offset-0", "aria-invalid:border-destructive aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/apps/web/src/components/ui/input.tsx",
        lineNumber: 32,
        columnNumber: 5
    }, this);
}
_c = Input;
;
var _c;
__turbopack_context__.k.register(_c, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/apps/web/src/components/ui/label.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "Label": (()=>Label),
    "labelVariants": (()=>labelVariants)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.3_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$label$40$2$2e$1$2e$7_$40$types$2b$react$2d$dom$40$19$2e$1$2e$6_$40$types$2b$react$40$19$2e$1$2e$8_$5f40$types$2b$react$40$1_f026c130782473ba8001b4f96e481e94$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@radix-ui+react-label@2.1.7_@types+react-dom@19.1.6_@types+react@19.1.8__@types+react@1_f026c130782473ba8001b4f96e481e94/node_modules/@radix-ui/react-label/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$class$2d$variance$2d$authority$40$0$2e$7$2e$1$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/class-variance-authority@0.7.1/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
const labelVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$class$2d$variance$2d$authority$40$0$2e$7$2e$1$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("flex items-center gap-2 leading-none select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50", {
    variants: {
        size: {
            sm: "text-xs",
            md: "text-sm",
            lg: "text-base"
        },
        weight: {
            normal: "font-medium",
            bold: "font-bold"
        }
    },
    defaultVariants: {
        size: "md",
        weight: "normal"
    }
});
function Label({ className, size, weight, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$label$40$2$2e$1$2e$7_$40$types$2b$react$2d$dom$40$19$2e$1$2e$6_$40$types$2b$react$40$19$2e$1$2e$8_$5f40$types$2b$react$40$1_f026c130782473ba8001b4f96e481e94$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "label",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(labelVariants({
            size,
            weight
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/apps/web/src/components/ui/label.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
_c = Label;
;
var _c;
__turbopack_context__.k.register(_c, "Label");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/apps/web/src/components/ui/Skeleton.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "Skeleton": (()=>Skeleton)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.3_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$class$2d$variance$2d$authority$40$0$2e$7$2e$1$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/class-variance-authority@0.7.1/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const skeletonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$class$2d$variance$2d$authority$40$0$2e$7$2e$1$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("animate-pulse bg-[var(--border)]", {
    variants: {
        shape: {
            boxy: "rounded-none",
            rounded: "rounded-md",
            pill: "rounded-full"
        },
        size: {
            sm: "h-4",
            md: "h-6",
            lg: "h-10"
        },
        width: {
            sm: "w-16",
            md: "w-32",
            lg: "w-64",
            full: "w-full"
        }
    },
    defaultVariants: {
        shape: "rounded",
        size: "md",
        width: "full"
    }
});
function Skeleton({ className, shape, size, width, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(skeletonVariants({
            shape,
            size,
            width
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/apps/web/src/components/ui/Skeleton.tsx",
        lineNumber: 38,
        columnNumber: 5
    }, this);
}
_c = Skeleton;
var _c;
__turbopack_context__.k.register(_c, "Skeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/apps/web/src/lib/api.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// API utilities for file uploads and other operations
__turbopack_context__.s({
    "apiClient": (()=>apiClient),
    "decodeJwtPayload": (()=>decodeJwtPayload),
    "mutator": (()=>mutator),
    "uploadWithProgress": (()=>uploadWithProgress)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.3_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.3_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/buffer/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$axios$40$1$2e$10$2e$0$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/axios@1.10.0/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$store$2f$useAuthStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/store/useAuthStore.ts [app-client] (ecmascript)");
;
;
// Get the appropriate API base URL based on environment
const getBaseURL = ()=>{
    const isServer = "object" === 'undefined';
    // Server-side (Next.js SSR/API Routes running in Docker)
    if ("TURBOPACK compile-time falsy", 0) {
        "TURBOPACK unreachable";
    }
    // Client-side (browser) - use the public environment variable
    // This is exposed by NEXT_PUBLIC_ prefix and accessible to the browser
    // Browser needs localhost because it runs on the host machine, not in Docker
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';
};
const axiosInstance = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$axios$40$1$2e$10$2e$0$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    headers: {
        "Content-Type": "application/json"
    }
});
// Request interceptor to add auth token and set dynamic base URL
axiosInstance.interceptors.request.use((config)=>{
    // Set base URL dynamically based on environment (server vs browser)
    config.baseURL = getBaseURL();
    // Get token directly from Zustand store
    const token = __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$store$2f$useAuthStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"].getState().token;
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
}, (error)=>{
    return Promise.reject(error);
});
// Response interceptor for error handling
axiosInstance.interceptors.response.use((response)=>response, (error)=>{
    // Handle 401 Unauthorized - redirect to login
    if (error.response?.status === 401) {
        // Don't redirect if we're already on the login page
        if ("object" !== "undefined" && window.location.pathname !== "/login") {
            // Clear auth data using the store
            __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$store$2f$useAuthStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"].getState().logout();
            // Show toast notification (only in browser)
            if ("TURBOPACK compile-time truthy", 1) {
                __turbopack_context__.r("[project]/apps/web/src/lib/toast.ts [app-client] (ecmascript, async loader)")(__turbopack_context__.i).then(({ showWarning })=>{
                    showWarning('Session expired', {
                        description: 'Please log in again to continue.'
                    });
                });
            }
            // Redirect to login
            window.location.href = "/login";
        }
    }
    // Handle 403 Forbidden
    if (error.response?.status === 403 && "object" !== "undefined") {
        __turbopack_context__.r("[project]/apps/web/src/lib/toast.ts [app-client] (ecmascript, async loader)")(__turbopack_context__.i).then(({ showError })=>{
            showError('Access denied', {
                description: 'You do not have permission to perform this action.'
            });
        });
    }
    // Handle 429 Rate Limit
    if (error.response?.status === 429 && "object" !== "undefined") {
        const retryAfter = error.response.headers['retry-after'];
        __turbopack_context__.r("[project]/apps/web/src/lib/toast.ts [app-client] (ecmascript, async loader)")(__turbopack_context__.i).then(({ showWarning })=>{
            showWarning('Too many requests', {
                description: retryAfter ? `Please wait ${retryAfter} seconds before trying again.` : 'Please wait a moment and try again.'
            });
        });
    }
    // Handle 500 Server Error
    if (error.response?.status === 500 && "object" !== "undefined") {
        __turbopack_context__.r("[project]/apps/web/src/lib/toast.ts [app-client] (ecmascript, async loader)")(__turbopack_context__.i).then(({ showError })=>{
            showError('Server error', {
                description: 'Something went wrong on our end. Please try again later.'
            });
        });
    }
    // Handle Network Errors
    if (error.message === 'Network Error' && "object" !== "undefined") {
        __turbopack_context__.r("[project]/apps/web/src/lib/toast.ts [app-client] (ecmascript, async loader)")(__turbopack_context__.i).then(({ showError })=>{
            showError('Network error', {
                description: 'Unable to connect to the server. Please check your internet connection.'
            });
        });
    }
    return Promise.reject(error);
});
const mutator = async (config, options)=>{
    try {
        const response = await axiosInstance({
            ...config,
            ...options
        });
        return response.data;
    } catch (error) {
        // Re-throw the error for React Query to handle
        throw error;
    }
};
async function uploadWithProgress(url, file, options = {}) {
    const { onProgress, signal } = options;
    // Simulate upload progress but cap at 95% until completion
    return new Promise((resolve)=>{
        let progress = 0;
        const interval = setInterval(()=>{
            progress = Math.min(progress + 5, 95);
            onProgress?.({
                loaded: progress,
                total: 100,
                percentage: progress
            });
        }, 200);
        const complete = ()=>{
            clearInterval(interval);
            onProgress?.({
                loaded: 100,
                total: 100,
                percentage: 100
            });
            resolve({
                url: URL.createObjectURL(file),
                name: file.name,
                size: file.size
            });
        };
        // Simulate completion after a short delay (replace with real upload completion)
        const doneTimer = setTimeout(complete, 2000);
        // Handle abort signal
        if (signal) {
            signal.addEventListener("abort", ()=>{
                clearInterval(interval);
                clearTimeout(doneTimer);
            });
        }
    });
}
function decodeJwtPayload(token) {
    if (!token) return null;
    try {
        const payload = token.split(".")[1];
        // Use atob if available (browser/edge), otherwise Buffer (Node.js)
        let decoded;
        if (typeof atob === "function") {
            decoded = atob(payload.replace(/-/g, "+").replace(/_/g, "/"));
        } else {
            // Node.js polyfill
            decoded = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(payload, "base64").toString("utf-8");
        }
        return JSON.parse(decoded);
    } catch  {
        return null;
    }
}
const apiClient = {
    uploadWithProgress,
    // Base fetch wrapper
    async fetch (url, options = {}) {
        const response = await fetch(url, {
            ...options,
            headers: {
                "Content-Type": "application/json",
                ...options.headers
            }
        });
        if (!response.ok) {
            throw new Error(`API request failed: ${response.status} ${response.statusText}`);
        }
        return response;
    },
    // GET request
    async get (url, options = {}) {
        const response = await this.fetch(url, {
            ...options,
            method: "GET"
        });
        return response.json();
    },
    // POST request
    async post (url, data, options = {}) {
        const response = await this.fetch(url, {
            ...options,
            method: "POST",
            body: JSON.stringify(data)
        });
        return response.json();
    },
    // PUT request
    async put (url, data, options = {}) {
        const response = await this.fetch(url, {
            ...options,
            method: "PUT",
            body: JSON.stringify(data)
        });
        return response.json();
    },
    // DELETE request
    async delete (url, options = {}) {
        const response = await this.fetch(url, {
            ...options,
            method: "DELETE"
        });
        return response.json();
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/endpoints/admin/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * // 🚀 Auto-generated by Orval (Axios + React Query)
 * // 🔄 Do not edit manually - regenerate with: pnpm generate-types
 * // 📁 Organized by FastAPI tags for maximum maintainability
 * // 🔐 Uses custom Axios instance with auth & error handling
 * 
 */ __turbopack_context__.s({
    "getAdminAuditLogs": (()=>getAdminAuditLogs),
    "getAdminAuditLogs$LogId": (()=>getAdminAuditLogs$LogId),
    "getAdminAuditLogsEntity$EntityType$EntityId": (()=>getAdminAuditLogsEntity$EntityType$EntityId),
    "getAdminAuditLogsExport": (()=>getAdminAuditLogsExport),
    "getAdminCyclesActive": (()=>getAdminCyclesActive),
    "getAdminDeadlinesOverrides": (()=>getAdminDeadlinesOverrides),
    "getAdminDeadlinesOverridesExport": (()=>getAdminDeadlinesOverridesExport),
    "getAdminDeadlinesStatus": (()=>getAdminDeadlinesStatus),
    "getAdminSystemStatus": (()=>getAdminSystemStatus),
    "getGetAdminAuditLogsEntityEntityTypeEntityIdQueryKey": (()=>getGetAdminAuditLogsEntityEntityTypeEntityIdQueryKey),
    "getGetAdminAuditLogsEntityEntityTypeEntityIdQueryOptions": (()=>getGetAdminAuditLogsEntityEntityTypeEntityIdQueryOptions),
    "getGetAdminAuditLogsExportQueryKey": (()=>getGetAdminAuditLogsExportQueryKey),
    "getGetAdminAuditLogsExportQueryOptions": (()=>getGetAdminAuditLogsExportQueryOptions),
    "getGetAdminAuditLogsLogIdQueryKey": (()=>getGetAdminAuditLogsLogIdQueryKey),
    "getGetAdminAuditLogsLogIdQueryOptions": (()=>getGetAdminAuditLogsLogIdQueryOptions),
    "getGetAdminAuditLogsQueryKey": (()=>getGetAdminAuditLogsQueryKey),
    "getGetAdminAuditLogsQueryOptions": (()=>getGetAdminAuditLogsQueryOptions),
    "getGetAdminCyclesActiveQueryKey": (()=>getGetAdminCyclesActiveQueryKey),
    "getGetAdminCyclesActiveQueryOptions": (()=>getGetAdminCyclesActiveQueryOptions),
    "getGetAdminDeadlinesOverridesExportQueryKey": (()=>getGetAdminDeadlinesOverridesExportQueryKey),
    "getGetAdminDeadlinesOverridesExportQueryOptions": (()=>getGetAdminDeadlinesOverridesExportQueryOptions),
    "getGetAdminDeadlinesOverridesQueryKey": (()=>getGetAdminDeadlinesOverridesQueryKey),
    "getGetAdminDeadlinesOverridesQueryOptions": (()=>getGetAdminDeadlinesOverridesQueryOptions),
    "getGetAdminDeadlinesStatusQueryKey": (()=>getGetAdminDeadlinesStatusQueryKey),
    "getGetAdminDeadlinesStatusQueryOptions": (()=>getGetAdminDeadlinesStatusQueryOptions),
    "getGetAdminSystemStatusQueryKey": (()=>getGetAdminSystemStatusQueryKey),
    "getGetAdminSystemStatusQueryOptions": (()=>getGetAdminSystemStatusQueryOptions),
    "getPostAdminCyclesMutationOptions": (()=>getPostAdminCyclesMutationOptions),
    "getPostAdminDeadlinesOverrideMutationOptions": (()=>getPostAdminDeadlinesOverrideMutationOptions),
    "getPutAdminCyclesCycleIdMutationOptions": (()=>getPutAdminCyclesCycleIdMutationOptions),
    "postAdminCycles": (()=>postAdminCycles),
    "postAdminDeadlinesOverride": (()=>postAdminDeadlinesOverride),
    "putAdminCycles$CycleId": (()=>putAdminCycles$CycleId),
    "useGetAdminAuditLogs": (()=>useGetAdminAuditLogs),
    "useGetAdminAuditLogsEntityEntityTypeEntityId": (()=>useGetAdminAuditLogsEntityEntityTypeEntityId),
    "useGetAdminAuditLogsExport": (()=>useGetAdminAuditLogsExport),
    "useGetAdminAuditLogsLogId": (()=>useGetAdminAuditLogsLogId),
    "useGetAdminCyclesActive": (()=>useGetAdminCyclesActive),
    "useGetAdminDeadlinesOverrides": (()=>useGetAdminDeadlinesOverrides),
    "useGetAdminDeadlinesOverridesExport": (()=>useGetAdminDeadlinesOverridesExport),
    "useGetAdminDeadlinesStatus": (()=>useGetAdminDeadlinesStatus),
    "useGetAdminSystemStatus": (()=>useGetAdminSystemStatus),
    "usePostAdminCycles": (()=>usePostAdminCycles),
    "usePostAdminDeadlinesOverride": (()=>usePostAdminDeadlinesOverride),
    "usePutAdminCyclesCycleId": (()=>usePutAdminCyclesCycleId)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/api.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature(), _s7 = __turbopack_context__.k.signature(), _s8 = __turbopack_context__.k.signature(), _s9 = __turbopack_context__.k.signature(), _s10 = __turbopack_context__.k.signature(), _s11 = __turbopack_context__.k.signature();
;
;
const getAdminAuditLogs = (params, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/admin/audit-logs`,
        method: 'GET',
        params,
        signal
    }, options);
};
const getGetAdminAuditLogsQueryKey = (params)=>{
    return [
        `http://localhost:8000/api/v1/admin/audit-logs`,
        ...params ? [
            params
        ] : []
    ];
};
const getGetAdminAuditLogsQueryOptions = (params, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAdminAuditLogsQueryKey(params);
    const queryFn = ({ signal })=>getAdminAuditLogs(params, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAdminAuditLogs(params, options) {
    _s();
    const queryOptions = getGetAdminAuditLogsQueryOptions(params, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s(useGetAdminAuditLogs, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const getAdminAuditLogs$LogId = (logId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/admin/audit-logs/${logId}`,
        method: 'GET',
        signal
    }, options);
};
const getGetAdminAuditLogsLogIdQueryKey = (logId)=>{
    return [
        `http://localhost:8000/api/v1/admin/audit-logs/${logId}`
    ];
};
const getGetAdminAuditLogsLogIdQueryOptions = (logId, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAdminAuditLogsLogIdQueryKey(logId);
    const queryFn = ({ signal })=>getAdminAuditLogs$LogId(logId, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        enabled: !!logId,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAdminAuditLogsLogId(logId, options) {
    _s1();
    const queryOptions = getGetAdminAuditLogsLogIdQueryOptions(logId, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s1(useGetAdminAuditLogsLogId, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const getAdminAuditLogsEntity$EntityType$EntityId = (entityType, entityId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/admin/audit-logs/entity/${entityType}/${entityId}`,
        method: 'GET',
        signal
    }, options);
};
const getGetAdminAuditLogsEntityEntityTypeEntityIdQueryKey = (entityType, entityId)=>{
    return [
        `http://localhost:8000/api/v1/admin/audit-logs/entity/${entityType}/${entityId}`
    ];
};
const getGetAdminAuditLogsEntityEntityTypeEntityIdQueryOptions = (entityType, entityId, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAdminAuditLogsEntityEntityTypeEntityIdQueryKey(entityType, entityId);
    const queryFn = ({ signal })=>getAdminAuditLogsEntity$EntityType$EntityId(entityType, entityId, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        enabled: !!(entityType && entityId),
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAdminAuditLogsEntityEntityTypeEntityId(entityType, entityId, options) {
    _s2();
    const queryOptions = getGetAdminAuditLogsEntityEntityTypeEntityIdQueryOptions(entityType, entityId, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s2(useGetAdminAuditLogsEntityEntityTypeEntityId, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const getAdminAuditLogsExport = (params, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/admin/audit-logs/export`,
        method: 'GET',
        params,
        signal
    }, options);
};
const getGetAdminAuditLogsExportQueryKey = (params)=>{
    return [
        `http://localhost:8000/api/v1/admin/audit-logs/export`,
        ...params ? [
            params
        ] : []
    ];
};
const getGetAdminAuditLogsExportQueryOptions = (params, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAdminAuditLogsExportQueryKey(params);
    const queryFn = ({ signal })=>getAdminAuditLogsExport(params, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAdminAuditLogsExport(params, options) {
    _s3();
    const queryOptions = getGetAdminAuditLogsExportQueryOptions(params, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s3(useGetAdminAuditLogsExport, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const postAdminCycles = (assessmentCycleCreate, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/admin/cycles`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        data: assessmentCycleCreate,
        signal
    }, options);
};
const getPostAdminCyclesMutationOptions = (options)=>{
    const mutationKey = [
        'postAdminCycles'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { data } = props ?? {};
        return postAdminCycles(data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAdminCycles = (options)=>{
    _s4();
    const mutationOptions = getPostAdminCyclesMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s4(usePostAdminCycles, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const getAdminCyclesActive = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/admin/cycles/active`,
        method: 'GET',
        signal
    }, options);
};
const getGetAdminCyclesActiveQueryKey = ()=>{
    return [
        `http://localhost:8000/api/v1/admin/cycles/active`
    ];
};
const getGetAdminCyclesActiveQueryOptions = (options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAdminCyclesActiveQueryKey();
    const queryFn = ({ signal })=>getAdminCyclesActive(requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAdminCyclesActive(options) {
    _s5();
    const queryOptions = getGetAdminCyclesActiveQueryOptions(options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s5(useGetAdminCyclesActive, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const putAdminCycles$CycleId = (cycleId, assessmentCycleUpdate, options)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/admin/cycles/${cycleId}`,
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        data: assessmentCycleUpdate
    }, options);
};
const getPutAdminCyclesCycleIdMutationOptions = (options)=>{
    const mutationKey = [
        'putAdminCyclesCycleId'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { cycleId, data } = props ?? {};
        return putAdminCycles$CycleId(cycleId, data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePutAdminCyclesCycleId = (options)=>{
    _s6();
    const mutationOptions = getPutAdminCyclesCycleIdMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s6(usePutAdminCyclesCycleId, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const getAdminDeadlinesStatus = (params, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/admin/deadlines/status`,
        method: 'GET',
        params,
        signal
    }, options);
};
const getGetAdminDeadlinesStatusQueryKey = (params)=>{
    return [
        `http://localhost:8000/api/v1/admin/deadlines/status`,
        ...params ? [
            params
        ] : []
    ];
};
const getGetAdminDeadlinesStatusQueryOptions = (params, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAdminDeadlinesStatusQueryKey(params);
    const queryFn = ({ signal })=>getAdminDeadlinesStatus(params, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAdminDeadlinesStatus(params, options) {
    _s7();
    const queryOptions = getGetAdminDeadlinesStatusQueryOptions(params, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s7(useGetAdminDeadlinesStatus, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const postAdminDeadlinesOverride = (deadlineOverrideCreate, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/admin/deadlines/override`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        data: deadlineOverrideCreate,
        signal
    }, options);
};
const getPostAdminDeadlinesOverrideMutationOptions = (options)=>{
    const mutationKey = [
        'postAdminDeadlinesOverride'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { data } = props ?? {};
        return postAdminDeadlinesOverride(data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAdminDeadlinesOverride = (options)=>{
    _s8();
    const mutationOptions = getPostAdminDeadlinesOverrideMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s8(usePostAdminDeadlinesOverride, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const getAdminDeadlinesOverrides = (params, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/admin/deadlines/overrides`,
        method: 'GET',
        params,
        signal
    }, options);
};
const getGetAdminDeadlinesOverridesQueryKey = (params)=>{
    return [
        `http://localhost:8000/api/v1/admin/deadlines/overrides`,
        ...params ? [
            params
        ] : []
    ];
};
const getGetAdminDeadlinesOverridesQueryOptions = (params, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAdminDeadlinesOverridesQueryKey(params);
    const queryFn = ({ signal })=>getAdminDeadlinesOverrides(params, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAdminDeadlinesOverrides(params, options) {
    _s9();
    const queryOptions = getGetAdminDeadlinesOverridesQueryOptions(params, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s9(useGetAdminDeadlinesOverrides, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const getAdminDeadlinesOverridesExport = (params, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/admin/deadlines/overrides/export`,
        method: 'GET',
        params,
        signal
    }, options);
};
const getGetAdminDeadlinesOverridesExportQueryKey = (params)=>{
    return [
        `http://localhost:8000/api/v1/admin/deadlines/overrides/export`,
        ...params ? [
            params
        ] : []
    ];
};
const getGetAdminDeadlinesOverridesExportQueryOptions = (params, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAdminDeadlinesOverridesExportQueryKey(params);
    const queryFn = ({ signal })=>getAdminDeadlinesOverridesExport(params, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAdminDeadlinesOverridesExport(params, options) {
    _s10();
    const queryOptions = getGetAdminDeadlinesOverridesExportQueryOptions(params, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s10(useGetAdminDeadlinesOverridesExport, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const getAdminSystemStatus = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/admin/system/status`,
        method: 'GET',
        signal
    }, options);
};
const getGetAdminSystemStatusQueryKey = ()=>{
    return [
        `http://localhost:8000/api/v1/admin/system/status`
    ];
};
const getGetAdminSystemStatusQueryOptions = (options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAdminSystemStatusQueryKey();
    const queryFn = ({ signal })=>getAdminSystemStatus(requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAdminSystemStatus(options) {
    _s11();
    const queryOptions = getGetAdminSystemStatusQueryOptions(options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s11(useGetAdminSystemStatus, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/endpoints/analytics/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * // 🚀 Auto-generated by Orval (Axios + React Query)
 * // 🔄 Do not edit manually - regenerate with: pnpm generate-types
 * // 📁 Organized by FastAPI tags for maximum maintainability
 * // 🔐 Uses custom Axios instance with auth & error handling
 * 
 */ __turbopack_context__.s({
    "getAnalyticsDashboard": (()=>getAnalyticsDashboard),
    "getAnalyticsReports": (()=>getAnalyticsReports),
    "getGetAnalyticsDashboardQueryKey": (()=>getGetAnalyticsDashboardQueryKey),
    "getGetAnalyticsDashboardQueryOptions": (()=>getGetAnalyticsDashboardQueryOptions),
    "getGetAnalyticsReportsQueryKey": (()=>getGetAnalyticsReportsQueryKey),
    "getGetAnalyticsReportsQueryOptions": (()=>getGetAnalyticsReportsQueryOptions),
    "useGetAnalyticsDashboard": (()=>useGetAnalyticsDashboard),
    "useGetAnalyticsReports": (()=>useGetAnalyticsReports)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/api.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
const getAnalyticsDashboard = (params, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/analytics/dashboard`,
        method: 'GET',
        params,
        signal
    }, options);
};
const getGetAnalyticsDashboardQueryKey = (params)=>{
    return [
        `http://localhost:8000/api/v1/analytics/dashboard`,
        ...params ? [
            params
        ] : []
    ];
};
const getGetAnalyticsDashboardQueryOptions = (params, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAnalyticsDashboardQueryKey(params);
    const queryFn = ({ signal })=>getAnalyticsDashboard(params, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAnalyticsDashboard(params, options) {
    _s();
    const queryOptions = getGetAnalyticsDashboardQueryOptions(params, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s(useGetAnalyticsDashboard, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const getAnalyticsReports = (params, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/analytics/reports`,
        method: 'GET',
        params,
        signal
    }, options);
};
const getGetAnalyticsReportsQueryKey = (params)=>{
    return [
        `http://localhost:8000/api/v1/analytics/reports`,
        ...params ? [
            params
        ] : []
    ];
};
const getGetAnalyticsReportsQueryOptions = (params, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAnalyticsReportsQueryKey(params);
    const queryFn = ({ signal })=>getAnalyticsReports(params, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAnalyticsReports(params, options) {
    _s1();
    const queryOptions = getGetAnalyticsReportsQueryOptions(params, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s1(useGetAnalyticsReports, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/endpoints/assessments/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * // 🚀 Auto-generated by Orval (Axios + React Query)
 * // 🔄 Do not edit manually - regenerate with: pnpm generate-types
 * // 📁 Organized by FastAPI tags for maximum maintainability
 * // 🔐 Uses custom Axios instance with auth & error handling
 * 
 */ __turbopack_context__.s({
    "deleteAssessmentsMovs$MovId": (()=>deleteAssessmentsMovs$MovId),
    "getAssessments$AssessmentIdAnswers": (()=>getAssessments$AssessmentIdAnswers),
    "getAssessmentsDashboard": (()=>getAssessmentsDashboard),
    "getAssessmentsList": (()=>getAssessmentsList),
    "getAssessmentsMyAssessment": (()=>getAssessmentsMyAssessment),
    "getAssessmentsResponses$ResponseId": (()=>getAssessmentsResponses$ResponseId),
    "getDeleteAssessmentsMovsMovIdMutationOptions": (()=>getDeleteAssessmentsMovsMovIdMutationOptions),
    "getGetAssessmentsAssessmentIdAnswersQueryKey": (()=>getGetAssessmentsAssessmentIdAnswersQueryKey),
    "getGetAssessmentsAssessmentIdAnswersQueryOptions": (()=>getGetAssessmentsAssessmentIdAnswersQueryOptions),
    "getGetAssessmentsDashboardQueryKey": (()=>getGetAssessmentsDashboardQueryKey),
    "getGetAssessmentsDashboardQueryOptions": (()=>getGetAssessmentsDashboardQueryOptions),
    "getGetAssessmentsListQueryKey": (()=>getGetAssessmentsListQueryKey),
    "getGetAssessmentsListQueryOptions": (()=>getGetAssessmentsListQueryOptions),
    "getGetAssessmentsMyAssessmentQueryKey": (()=>getGetAssessmentsMyAssessmentQueryKey),
    "getGetAssessmentsMyAssessmentQueryOptions": (()=>getGetAssessmentsMyAssessmentQueryOptions),
    "getGetAssessmentsResponsesResponseIdQueryKey": (()=>getGetAssessmentsResponsesResponseIdQueryKey),
    "getGetAssessmentsResponsesResponseIdQueryOptions": (()=>getGetAssessmentsResponsesResponseIdQueryOptions),
    "getPostAssessmentsAssessmentIdAnswersMutationOptions": (()=>getPostAssessmentsAssessmentIdAnswersMutationOptions),
    "getPostAssessmentsAssessmentIdSubmitMutationOptions": (()=>getPostAssessmentsAssessmentIdSubmitMutationOptions),
    "getPostAssessmentsAssessmentIdValidateCompletenessMutationOptions": (()=>getPostAssessmentsAssessmentIdValidateCompletenessMutationOptions),
    "getPostAssessmentsIdGenerateInsightsMutationOptions": (()=>getPostAssessmentsIdGenerateInsightsMutationOptions),
    "getPostAssessmentsResponsesMutationOptions": (()=>getPostAssessmentsResponsesMutationOptions),
    "getPostAssessmentsResponsesResponseIdMovsMutationOptions": (()=>getPostAssessmentsResponsesResponseIdMovsMutationOptions),
    "getPostAssessmentsSubmitMutationOptions": (()=>getPostAssessmentsSubmitMutationOptions),
    "getPutAssessmentsResponsesResponseIdMutationOptions": (()=>getPutAssessmentsResponsesResponseIdMutationOptions),
    "postAssessments$AssessmentIdAnswers": (()=>postAssessments$AssessmentIdAnswers),
    "postAssessments$AssessmentIdSubmit": (()=>postAssessments$AssessmentIdSubmit),
    "postAssessments$AssessmentIdValidateCompleteness": (()=>postAssessments$AssessmentIdValidateCompleteness),
    "postAssessments$IdGenerateInsights": (()=>postAssessments$IdGenerateInsights),
    "postAssessmentsResponses": (()=>postAssessmentsResponses),
    "postAssessmentsResponses$ResponseIdMovs": (()=>postAssessmentsResponses$ResponseIdMovs),
    "postAssessmentsSubmit": (()=>postAssessmentsSubmit),
    "putAssessmentsResponses$ResponseId": (()=>putAssessmentsResponses$ResponseId),
    "useDeleteAssessmentsMovsMovId": (()=>useDeleteAssessmentsMovsMovId),
    "useGetAssessmentsAssessmentIdAnswers": (()=>useGetAssessmentsAssessmentIdAnswers),
    "useGetAssessmentsDashboard": (()=>useGetAssessmentsDashboard),
    "useGetAssessmentsList": (()=>useGetAssessmentsList),
    "useGetAssessmentsMyAssessment": (()=>useGetAssessmentsMyAssessment),
    "useGetAssessmentsResponsesResponseId": (()=>useGetAssessmentsResponsesResponseId),
    "usePostAssessmentsAssessmentIdAnswers": (()=>usePostAssessmentsAssessmentIdAnswers),
    "usePostAssessmentsAssessmentIdSubmit": (()=>usePostAssessmentsAssessmentIdSubmit),
    "usePostAssessmentsAssessmentIdValidateCompleteness": (()=>usePostAssessmentsAssessmentIdValidateCompleteness),
    "usePostAssessmentsIdGenerateInsights": (()=>usePostAssessmentsIdGenerateInsights),
    "usePostAssessmentsResponses": (()=>usePostAssessmentsResponses),
    "usePostAssessmentsResponsesResponseIdMovs": (()=>usePostAssessmentsResponsesResponseIdMovs),
    "usePostAssessmentsSubmit": (()=>usePostAssessmentsSubmit),
    "usePutAssessmentsResponsesResponseId": (()=>usePutAssessmentsResponsesResponseId)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/api.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature(), _s7 = __turbopack_context__.k.signature(), _s8 = __turbopack_context__.k.signature(), _s9 = __turbopack_context__.k.signature(), _s10 = __turbopack_context__.k.signature(), _s11 = __turbopack_context__.k.signature(), _s12 = __turbopack_context__.k.signature(), _s13 = __turbopack_context__.k.signature();
;
;
const getAssessmentsDashboard = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessments/dashboard`,
        method: 'GET',
        signal
    }, options);
};
const getGetAssessmentsDashboardQueryKey = ()=>{
    return [
        `http://localhost:8000/api/v1/assessments/dashboard`
    ];
};
const getGetAssessmentsDashboardQueryOptions = (options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAssessmentsDashboardQueryKey();
    const queryFn = ({ signal })=>getAssessmentsDashboard(requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAssessmentsDashboard(options) {
    _s();
    const queryOptions = getGetAssessmentsDashboardQueryOptions(options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s(useGetAssessmentsDashboard, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const getAssessmentsMyAssessment = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessments/my-assessment`,
        method: 'GET',
        signal
    }, options);
};
const getGetAssessmentsMyAssessmentQueryKey = ()=>{
    return [
        `http://localhost:8000/api/v1/assessments/my-assessment`
    ];
};
const getGetAssessmentsMyAssessmentQueryOptions = (options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAssessmentsMyAssessmentQueryKey();
    const queryFn = ({ signal })=>getAssessmentsMyAssessment(requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAssessmentsMyAssessment(options) {
    _s1();
    const queryOptions = getGetAssessmentsMyAssessmentQueryOptions(options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s1(useGetAssessmentsMyAssessment, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const getAssessmentsResponses$ResponseId = (responseId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessments/responses/${responseId}`,
        method: 'GET',
        signal
    }, options);
};
const getGetAssessmentsResponsesResponseIdQueryKey = (responseId)=>{
    return [
        `http://localhost:8000/api/v1/assessments/responses/${responseId}`
    ];
};
const getGetAssessmentsResponsesResponseIdQueryOptions = (responseId, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAssessmentsResponsesResponseIdQueryKey(responseId);
    const queryFn = ({ signal })=>getAssessmentsResponses$ResponseId(responseId, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        enabled: !!responseId,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAssessmentsResponsesResponseId(responseId, options) {
    _s2();
    const queryOptions = getGetAssessmentsResponsesResponseIdQueryOptions(responseId, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s2(useGetAssessmentsResponsesResponseId, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const putAssessmentsResponses$ResponseId = (responseId, assessmentResponseUpdate, options)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessments/responses/${responseId}`,
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        data: assessmentResponseUpdate
    }, options);
};
const getPutAssessmentsResponsesResponseIdMutationOptions = (options)=>{
    const mutationKey = [
        'putAssessmentsResponsesResponseId'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { responseId, data } = props ?? {};
        return putAssessmentsResponses$ResponseId(responseId, data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePutAssessmentsResponsesResponseId = (options)=>{
    _s3();
    const mutationOptions = getPutAssessmentsResponsesResponseIdMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s3(usePutAssessmentsResponsesResponseId, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const postAssessmentsResponses = (assessmentResponseCreate, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessments/responses`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        data: assessmentResponseCreate,
        signal
    }, options);
};
const getPostAssessmentsResponsesMutationOptions = (options)=>{
    const mutationKey = [
        'postAssessmentsResponses'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { data } = props ?? {};
        return postAssessmentsResponses(data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAssessmentsResponses = (options)=>{
    _s4();
    const mutationOptions = getPostAssessmentsResponsesMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s4(usePostAssessmentsResponses, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const postAssessmentsSubmit = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessments/submit`,
        method: 'POST',
        signal
    }, options);
};
const getPostAssessmentsSubmitMutationOptions = (options)=>{
    const mutationKey = [
        'postAssessmentsSubmit'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = ()=>{
        return postAssessmentsSubmit(requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAssessmentsSubmit = (options)=>{
    _s5();
    const mutationOptions = getPostAssessmentsSubmitMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s5(usePostAssessmentsSubmit, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const postAssessments$AssessmentIdSubmit = (assessmentId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessments/${assessmentId}/submit`,
        method: 'POST',
        signal
    }, options);
};
const getPostAssessmentsAssessmentIdSubmitMutationOptions = (options)=>{
    const mutationKey = [
        'postAssessmentsAssessmentIdSubmit'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { assessmentId } = props ?? {};
        return postAssessments$AssessmentIdSubmit(assessmentId, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAssessmentsAssessmentIdSubmit = (options)=>{
    _s6();
    const mutationOptions = getPostAssessmentsAssessmentIdSubmitMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s6(usePostAssessmentsAssessmentIdSubmit, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const postAssessmentsResponses$ResponseIdMovs = (responseId, mOVCreate, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessments/responses/${responseId}/movs`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        data: mOVCreate,
        signal
    }, options);
};
const getPostAssessmentsResponsesResponseIdMovsMutationOptions = (options)=>{
    const mutationKey = [
        'postAssessmentsResponsesResponseIdMovs'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { responseId, data } = props ?? {};
        return postAssessmentsResponses$ResponseIdMovs(responseId, data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAssessmentsResponsesResponseIdMovs = (options)=>{
    _s7();
    const mutationOptions = getPostAssessmentsResponsesResponseIdMovsMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s7(usePostAssessmentsResponsesResponseIdMovs, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const deleteAssessmentsMovs$MovId = (movId, options)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessments/movs/${movId}`,
        method: 'DELETE'
    }, options);
};
const getDeleteAssessmentsMovsMovIdMutationOptions = (options)=>{
    const mutationKey = [
        'deleteAssessmentsMovsMovId'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { movId } = props ?? {};
        return deleteAssessmentsMovs$MovId(movId, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const useDeleteAssessmentsMovsMovId = (options)=>{
    _s8();
    const mutationOptions = getDeleteAssessmentsMovsMovIdMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s8(useDeleteAssessmentsMovsMovId, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const getAssessmentsList = (params, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessments/list`,
        method: 'GET',
        params,
        signal
    }, options);
};
const getGetAssessmentsListQueryKey = (params)=>{
    return [
        `http://localhost:8000/api/v1/assessments/list`,
        ...params ? [
            params
        ] : []
    ];
};
const getGetAssessmentsListQueryOptions = (params, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAssessmentsListQueryKey(params);
    const queryFn = ({ signal })=>getAssessmentsList(params, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAssessmentsList(params, options) {
    _s9();
    const queryOptions = getGetAssessmentsListQueryOptions(params, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s9(useGetAssessmentsList, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const postAssessments$IdGenerateInsights = (id, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessments/${id}/generate-insights`,
        method: 'POST',
        signal
    }, options);
};
const getPostAssessmentsIdGenerateInsightsMutationOptions = (options)=>{
    const mutationKey = [
        'postAssessmentsIdGenerateInsights'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { id } = props ?? {};
        return postAssessments$IdGenerateInsights(id, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAssessmentsIdGenerateInsights = (options)=>{
    _s10();
    const mutationOptions = getPostAssessmentsIdGenerateInsightsMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s10(usePostAssessmentsIdGenerateInsights, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const postAssessments$AssessmentIdAnswers = (assessmentId, saveAnswersRequest, params, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessments/${assessmentId}/answers`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        data: saveAnswersRequest,
        params,
        signal
    }, options);
};
const getPostAssessmentsAssessmentIdAnswersMutationOptions = (options)=>{
    const mutationKey = [
        'postAssessmentsAssessmentIdAnswers'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { assessmentId, data, params } = props ?? {};
        return postAssessments$AssessmentIdAnswers(assessmentId, data, params, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAssessmentsAssessmentIdAnswers = (options)=>{
    _s11();
    const mutationOptions = getPostAssessmentsAssessmentIdAnswersMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s11(usePostAssessmentsAssessmentIdAnswers, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const getAssessments$AssessmentIdAnswers = (assessmentId, params, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessments/${assessmentId}/answers`,
        method: 'GET',
        params,
        signal
    }, options);
};
const getGetAssessmentsAssessmentIdAnswersQueryKey = (assessmentId, params)=>{
    return [
        `http://localhost:8000/api/v1/assessments/${assessmentId}/answers`,
        ...params ? [
            params
        ] : []
    ];
};
const getGetAssessmentsAssessmentIdAnswersQueryOptions = (assessmentId, params, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAssessmentsAssessmentIdAnswersQueryKey(assessmentId, params);
    const queryFn = ({ signal })=>getAssessments$AssessmentIdAnswers(assessmentId, params, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        enabled: !!assessmentId,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAssessmentsAssessmentIdAnswers(assessmentId, params, options) {
    _s12();
    const queryOptions = getGetAssessmentsAssessmentIdAnswersQueryOptions(assessmentId, params, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s12(useGetAssessmentsAssessmentIdAnswers, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const postAssessments$AssessmentIdValidateCompleteness = (assessmentId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessments/${assessmentId}/validate-completeness`,
        method: 'POST',
        signal
    }, options);
};
const getPostAssessmentsAssessmentIdValidateCompletenessMutationOptions = (options)=>{
    const mutationKey = [
        'postAssessmentsAssessmentIdValidateCompleteness'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { assessmentId } = props ?? {};
        return postAssessments$AssessmentIdValidateCompleteness(assessmentId, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAssessmentsAssessmentIdValidateCompleteness = (options)=>{
    _s13();
    const mutationOptions = getPostAssessmentsAssessmentIdValidateCompletenessMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s13(usePostAssessmentsAssessmentIdValidateCompleteness, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/endpoints/assessor/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * // 🚀 Auto-generated by Orval (Axios + React Query)
 * // 🔄 Do not edit manually - regenerate with: pnpm generate-types
 * // 📁 Organized by FastAPI tags for maximum maintainability
 * // 🔐 Uses custom Axios instance with auth & error handling
 * 
 */ __turbopack_context__.s({
    "getAssessorAnalytics": (()=>getAssessorAnalytics),
    "getAssessorAssessments$AssessmentId": (()=>getAssessorAssessments$AssessmentId),
    "getAssessorQueue": (()=>getAssessorQueue),
    "getGetAssessorAnalyticsQueryKey": (()=>getGetAssessorAnalyticsQueryKey),
    "getGetAssessorAnalyticsQueryOptions": (()=>getGetAssessorAnalyticsQueryOptions),
    "getGetAssessorAssessmentsAssessmentIdQueryKey": (()=>getGetAssessorAssessmentsAssessmentIdQueryKey),
    "getGetAssessorAssessmentsAssessmentIdQueryOptions": (()=>getGetAssessorAssessmentsAssessmentIdQueryOptions),
    "getGetAssessorQueueQueryKey": (()=>getGetAssessorQueueQueryKey),
    "getGetAssessorQueueQueryOptions": (()=>getGetAssessorQueueQueryOptions),
    "getPostAssessorAssessmentResponsesResponseIdMovsMutationOptions": (()=>getPostAssessorAssessmentResponsesResponseIdMovsMutationOptions),
    "getPostAssessorAssessmentResponsesResponseIdMovsUploadMutationOptions": (()=>getPostAssessorAssessmentResponsesResponseIdMovsUploadMutationOptions),
    "getPostAssessorAssessmentResponsesResponseIdValidateMutationOptions": (()=>getPostAssessorAssessmentResponsesResponseIdValidateMutationOptions),
    "getPostAssessorAssessmentsAssessmentIdClassifyMutationOptions": (()=>getPostAssessorAssessmentsAssessmentIdClassifyMutationOptions),
    "getPostAssessorAssessmentsAssessmentIdFinalizeMutationOptions": (()=>getPostAssessorAssessmentsAssessmentIdFinalizeMutationOptions),
    "getPostAssessorAssessmentsAssessmentIdReworkMutationOptions": (()=>getPostAssessorAssessmentsAssessmentIdReworkMutationOptions),
    "postAssessorAssessmentResponses$ResponseIdMovs": (()=>postAssessorAssessmentResponses$ResponseIdMovs),
    "postAssessorAssessmentResponses$ResponseIdMovsUpload": (()=>postAssessorAssessmentResponses$ResponseIdMovsUpload),
    "postAssessorAssessmentResponses$ResponseIdValidate": (()=>postAssessorAssessmentResponses$ResponseIdValidate),
    "postAssessorAssessments$AssessmentIdClassify": (()=>postAssessorAssessments$AssessmentIdClassify),
    "postAssessorAssessments$AssessmentIdFinalize": (()=>postAssessorAssessments$AssessmentIdFinalize),
    "postAssessorAssessments$AssessmentIdRework": (()=>postAssessorAssessments$AssessmentIdRework),
    "useGetAssessorAnalytics": (()=>useGetAssessorAnalytics),
    "useGetAssessorAssessmentsAssessmentId": (()=>useGetAssessorAssessmentsAssessmentId),
    "useGetAssessorQueue": (()=>useGetAssessorQueue),
    "usePostAssessorAssessmentResponsesResponseIdMovs": (()=>usePostAssessorAssessmentResponsesResponseIdMovs),
    "usePostAssessorAssessmentResponsesResponseIdMovsUpload": (()=>usePostAssessorAssessmentResponsesResponseIdMovsUpload),
    "usePostAssessorAssessmentResponsesResponseIdValidate": (()=>usePostAssessorAssessmentResponsesResponseIdValidate),
    "usePostAssessorAssessmentsAssessmentIdClassify": (()=>usePostAssessorAssessmentsAssessmentIdClassify),
    "usePostAssessorAssessmentsAssessmentIdFinalize": (()=>usePostAssessorAssessmentsAssessmentIdFinalize),
    "usePostAssessorAssessmentsAssessmentIdRework": (()=>usePostAssessorAssessmentsAssessmentIdRework)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/api.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature(), _s7 = __turbopack_context__.k.signature(), _s8 = __turbopack_context__.k.signature();
;
;
const getAssessorQueue = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessor/queue`,
        method: 'GET',
        signal
    }, options);
};
const getGetAssessorQueueQueryKey = ()=>{
    return [
        `http://localhost:8000/api/v1/assessor/queue`
    ];
};
const getGetAssessorQueueQueryOptions = (options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAssessorQueueQueryKey();
    const queryFn = ({ signal })=>getAssessorQueue(requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAssessorQueue(options) {
    _s();
    const queryOptions = getGetAssessorQueueQueryOptions(options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s(useGetAssessorQueue, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const postAssessorAssessmentResponses$ResponseIdValidate = (responseId, validationRequest, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessor/assessment-responses/${responseId}/validate`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        data: validationRequest,
        signal
    }, options);
};
const getPostAssessorAssessmentResponsesResponseIdValidateMutationOptions = (options)=>{
    const mutationKey = [
        'postAssessorAssessmentResponsesResponseIdValidate'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { responseId, data } = props ?? {};
        return postAssessorAssessmentResponses$ResponseIdValidate(responseId, data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAssessorAssessmentResponsesResponseIdValidate = (options)=>{
    _s1();
    const mutationOptions = getPostAssessorAssessmentResponsesResponseIdValidateMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s1(usePostAssessorAssessmentResponsesResponseIdValidate, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const postAssessorAssessmentResponses$ResponseIdMovs = (responseId, mOVCreate, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessor/assessment-responses/${responseId}/movs`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        data: mOVCreate,
        signal
    }, options);
};
const getPostAssessorAssessmentResponsesResponseIdMovsMutationOptions = (options)=>{
    const mutationKey = [
        'postAssessorAssessmentResponsesResponseIdMovs'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { responseId, data } = props ?? {};
        return postAssessorAssessmentResponses$ResponseIdMovs(responseId, data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAssessorAssessmentResponsesResponseIdMovs = (options)=>{
    _s2();
    const mutationOptions = getPostAssessorAssessmentResponsesResponseIdMovsMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s2(usePostAssessorAssessmentResponsesResponseIdMovs, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const postAssessorAssessmentResponses$ResponseIdMovsUpload = (responseId, bodyUploadMovFileForAssessorApiV1AssessorAssessmentResponsesResponseIdMovsUploadPost, options, signal)=>{
    const formData = new FormData();
    formData.append(`file`, bodyUploadMovFileForAssessorApiV1AssessorAssessmentResponsesResponseIdMovsUploadPost.file);
    if (bodyUploadMovFileForAssessorApiV1AssessorAssessmentResponsesResponseIdMovsUploadPost.filename !== undefined && bodyUploadMovFileForAssessorApiV1AssessorAssessmentResponsesResponseIdMovsUploadPost.filename !== null) {
        formData.append(`filename`, bodyUploadMovFileForAssessorApiV1AssessorAssessmentResponsesResponseIdMovsUploadPost.filename);
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessor/assessment-responses/${responseId}/movs/upload`,
        method: 'POST',
        headers: {
            'Content-Type': 'multipart/form-data'
        },
        data: formData,
        signal
    }, options);
};
const getPostAssessorAssessmentResponsesResponseIdMovsUploadMutationOptions = (options)=>{
    const mutationKey = [
        'postAssessorAssessmentResponsesResponseIdMovsUpload'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { responseId, data } = props ?? {};
        return postAssessorAssessmentResponses$ResponseIdMovsUpload(responseId, data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAssessorAssessmentResponsesResponseIdMovsUpload = (options)=>{
    _s3();
    const mutationOptions = getPostAssessorAssessmentResponsesResponseIdMovsUploadMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s3(usePostAssessorAssessmentResponsesResponseIdMovsUpload, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const getAssessorAssessments$AssessmentId = (assessmentId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessor/assessments/${assessmentId}`,
        method: 'GET',
        signal
    }, options);
};
const getGetAssessorAssessmentsAssessmentIdQueryKey = (assessmentId)=>{
    return [
        `http://localhost:8000/api/v1/assessor/assessments/${assessmentId}`
    ];
};
const getGetAssessorAssessmentsAssessmentIdQueryOptions = (assessmentId, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAssessorAssessmentsAssessmentIdQueryKey(assessmentId);
    const queryFn = ({ signal })=>getAssessorAssessments$AssessmentId(assessmentId, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        enabled: !!assessmentId,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAssessorAssessmentsAssessmentId(assessmentId, options) {
    _s4();
    const queryOptions = getGetAssessorAssessmentsAssessmentIdQueryOptions(assessmentId, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s4(useGetAssessorAssessmentsAssessmentId, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const postAssessorAssessments$AssessmentIdRework = (assessmentId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessor/assessments/${assessmentId}/rework`,
        method: 'POST',
        signal
    }, options);
};
const getPostAssessorAssessmentsAssessmentIdReworkMutationOptions = (options)=>{
    const mutationKey = [
        'postAssessorAssessmentsAssessmentIdRework'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { assessmentId } = props ?? {};
        return postAssessorAssessments$AssessmentIdRework(assessmentId, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAssessorAssessmentsAssessmentIdRework = (options)=>{
    _s5();
    const mutationOptions = getPostAssessorAssessmentsAssessmentIdReworkMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s5(usePostAssessorAssessmentsAssessmentIdRework, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const postAssessorAssessments$AssessmentIdFinalize = (assessmentId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessor/assessments/${assessmentId}/finalize`,
        method: 'POST',
        signal
    }, options);
};
const getPostAssessorAssessmentsAssessmentIdFinalizeMutationOptions = (options)=>{
    const mutationKey = [
        'postAssessorAssessmentsAssessmentIdFinalize'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { assessmentId } = props ?? {};
        return postAssessorAssessments$AssessmentIdFinalize(assessmentId, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAssessorAssessmentsAssessmentIdFinalize = (options)=>{
    _s6();
    const mutationOptions = getPostAssessorAssessmentsAssessmentIdFinalizeMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s6(usePostAssessorAssessmentsAssessmentIdFinalize, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const postAssessorAssessments$AssessmentIdClassify = (assessmentId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessor/assessments/${assessmentId}/classify`,
        method: 'POST',
        signal
    }, options);
};
const getPostAssessorAssessmentsAssessmentIdClassifyMutationOptions = (options)=>{
    const mutationKey = [
        'postAssessorAssessmentsAssessmentIdClassify'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { assessmentId } = props ?? {};
        return postAssessorAssessments$AssessmentIdClassify(assessmentId, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAssessorAssessmentsAssessmentIdClassify = (options)=>{
    _s7();
    const mutationOptions = getPostAssessorAssessmentsAssessmentIdClassifyMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s7(usePostAssessorAssessmentsAssessmentIdClassify, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const getAssessorAnalytics = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/assessor/analytics`,
        method: 'GET',
        signal
    }, options);
};
const getGetAssessorAnalyticsQueryKey = ()=>{
    return [
        `http://localhost:8000/api/v1/assessor/analytics`
    ];
};
const getGetAssessorAnalyticsQueryOptions = (options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetAssessorAnalyticsQueryKey();
    const queryFn = ({ signal })=>getAssessorAnalytics(requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetAssessorAnalytics(options) {
    _s8();
    const queryOptions = getGetAssessorAnalyticsQueryOptions(options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s8(useGetAssessorAnalytics, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/endpoints/auth/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * // 🚀 Auto-generated by Orval (Axios + React Query)
 * // 🔄 Do not edit manually - regenerate with: pnpm generate-types
 * // 📁 Organized by FastAPI tags for maximum maintainability
 * // 🔐 Uses custom Axios instance with auth & error handling
 * 
 */ __turbopack_context__.s({
    "getPostAuthChangePasswordMutationOptions": (()=>getPostAuthChangePasswordMutationOptions),
    "getPostAuthLoginMutationOptions": (()=>getPostAuthLoginMutationOptions),
    "getPostAuthLogoutMutationOptions": (()=>getPostAuthLogoutMutationOptions),
    "postAuthChangePassword": (()=>postAuthChangePassword),
    "postAuthLogin": (()=>postAuthLogin),
    "postAuthLogout": (()=>postAuthLogout),
    "usePostAuthChangePassword": (()=>usePostAuthChangePassword),
    "usePostAuthLogin": (()=>usePostAuthLogin),
    "usePostAuthLogout": (()=>usePostAuthLogout)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/api.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
;
;
const postAuthLogin = (loginRequest, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/auth/login`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        data: loginRequest,
        signal
    }, options);
};
const getPostAuthLoginMutationOptions = (options)=>{
    const mutationKey = [
        'postAuthLogin'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { data } = props ?? {};
        return postAuthLogin(data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAuthLogin = (options)=>{
    _s();
    const mutationOptions = getPostAuthLoginMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s(usePostAuthLogin, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const postAuthChangePassword = (changePasswordRequest, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/auth/change-password`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        data: changePasswordRequest,
        signal
    }, options);
};
const getPostAuthChangePasswordMutationOptions = (options)=>{
    const mutationKey = [
        'postAuthChangePassword'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { data } = props ?? {};
        return postAuthChangePassword(data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAuthChangePassword = (options)=>{
    _s1();
    const mutationOptions = getPostAuthChangePasswordMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s1(usePostAuthChangePassword, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const postAuthLogout = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/auth/logout`,
        method: 'POST',
        signal
    }, options);
};
const getPostAuthLogoutMutationOptions = (options)=>{
    const mutationKey = [
        'postAuthLogout'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = ()=>{
        return postAuthLogout(requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostAuthLogout = (options)=>{
    _s2();
    const mutationOptions = getPostAuthLogoutMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s2(usePostAuthLogout, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/endpoints/bbis/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * // 🚀 Auto-generated by Orval (Axios + React Query)
 * // 🔄 Do not edit manually - regenerate with: pnpm generate-types
 * // 📁 Organized by FastAPI tags for maximum maintainability
 * // 🔐 Uses custom Axios instance with auth & error handling
 * 
 */ __turbopack_context__.s({
    "deleteBbis$BbiId": (()=>deleteBbis$BbiId),
    "getBbis": (()=>getBbis),
    "getBbis$BbiId": (()=>getBbis$BbiId),
    "getBbisResultsAssessment$AssessmentId": (()=>getBbisResultsAssessment$AssessmentId),
    "getDeleteBbisBbiIdMutationOptions": (()=>getDeleteBbisBbiIdMutationOptions),
    "getGetBbisBbiIdQueryKey": (()=>getGetBbisBbiIdQueryKey),
    "getGetBbisBbiIdQueryOptions": (()=>getGetBbisBbiIdQueryOptions),
    "getGetBbisQueryKey": (()=>getGetBbisQueryKey),
    "getGetBbisQueryOptions": (()=>getGetBbisQueryOptions),
    "getGetBbisResultsAssessmentAssessmentIdQueryKey": (()=>getGetBbisResultsAssessmentAssessmentIdQueryKey),
    "getGetBbisResultsAssessmentAssessmentIdQueryOptions": (()=>getGetBbisResultsAssessmentAssessmentIdQueryOptions),
    "getPostBbisMutationOptions": (()=>getPostBbisMutationOptions),
    "getPostBbisTestCalculationMutationOptions": (()=>getPostBbisTestCalculationMutationOptions),
    "getPutBbisBbiIdMutationOptions": (()=>getPutBbisBbiIdMutationOptions),
    "postBbis": (()=>postBbis),
    "postBbisTestCalculation": (()=>postBbisTestCalculation),
    "putBbis$BbiId": (()=>putBbis$BbiId),
    "useDeleteBbisBbiId": (()=>useDeleteBbisBbiId),
    "useGetBbis": (()=>useGetBbis),
    "useGetBbisBbiId": (()=>useGetBbisBbiId),
    "useGetBbisResultsAssessmentAssessmentId": (()=>useGetBbisResultsAssessmentAssessmentId),
    "usePostBbis": (()=>usePostBbis),
    "usePostBbisTestCalculation": (()=>usePostBbisTestCalculation),
    "usePutBbisBbiId": (()=>usePutBbisBbiId)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/api.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature();
;
;
const postBbis = (bBICreate, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/bbis/`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        data: bBICreate,
        signal
    }, options);
};
const getPostBbisMutationOptions = (options)=>{
    const mutationKey = [
        'postBbis'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { data } = props ?? {};
        return postBbis(data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostBbis = (options)=>{
    _s();
    const mutationOptions = getPostBbisMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s(usePostBbis, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const getBbis = (params, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/bbis/`,
        method: 'GET',
        params,
        signal
    }, options);
};
const getGetBbisQueryKey = (params)=>{
    return [
        `http://localhost:8000/api/v1/bbis/`,
        ...params ? [
            params
        ] : []
    ];
};
const getGetBbisQueryOptions = (params, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetBbisQueryKey(params);
    const queryFn = ({ signal })=>getBbis(params, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetBbis(params, options) {
    _s1();
    const queryOptions = getGetBbisQueryOptions(params, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s1(useGetBbis, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const getBbis$BbiId = (bbiId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/bbis/${bbiId}`,
        method: 'GET',
        signal
    }, options);
};
const getGetBbisBbiIdQueryKey = (bbiId)=>{
    return [
        `http://localhost:8000/api/v1/bbis/${bbiId}`
    ];
};
const getGetBbisBbiIdQueryOptions = (bbiId, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetBbisBbiIdQueryKey(bbiId);
    const queryFn = ({ signal })=>getBbis$BbiId(bbiId, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        enabled: !!bbiId,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetBbisBbiId(bbiId, options) {
    _s2();
    const queryOptions = getGetBbisBbiIdQueryOptions(bbiId, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s2(useGetBbisBbiId, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const putBbis$BbiId = (bbiId, bBIUpdate, options)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/bbis/${bbiId}`,
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        data: bBIUpdate
    }, options);
};
const getPutBbisBbiIdMutationOptions = (options)=>{
    const mutationKey = [
        'putBbisBbiId'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { bbiId, data } = props ?? {};
        return putBbis$BbiId(bbiId, data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePutBbisBbiId = (options)=>{
    _s3();
    const mutationOptions = getPutBbisBbiIdMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s3(usePutBbisBbiId, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const deleteBbis$BbiId = (bbiId, options)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/bbis/${bbiId}`,
        method: 'DELETE'
    }, options);
};
const getDeleteBbisBbiIdMutationOptions = (options)=>{
    const mutationKey = [
        'deleteBbisBbiId'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { bbiId } = props ?? {};
        return deleteBbis$BbiId(bbiId, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const useDeleteBbisBbiId = (options)=>{
    _s4();
    const mutationOptions = getDeleteBbisBbiIdMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s4(useDeleteBbisBbiId, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const postBbisTestCalculation = (testBBICalculationRequest, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/bbis/test-calculation`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        data: testBBICalculationRequest,
        signal
    }, options);
};
const getPostBbisTestCalculationMutationOptions = (options)=>{
    const mutationKey = [
        'postBbisTestCalculation'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { data } = props ?? {};
        return postBbisTestCalculation(data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostBbisTestCalculation = (options)=>{
    _s5();
    const mutationOptions = getPostBbisTestCalculationMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s5(usePostBbisTestCalculation, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const getBbisResultsAssessment$AssessmentId = (assessmentId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/bbis/results/assessment/${assessmentId}`,
        method: 'GET',
        signal
    }, options);
};
const getGetBbisResultsAssessmentAssessmentIdQueryKey = (assessmentId)=>{
    return [
        `http://localhost:8000/api/v1/bbis/results/assessment/${assessmentId}`
    ];
};
const getGetBbisResultsAssessmentAssessmentIdQueryOptions = (assessmentId, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetBbisResultsAssessmentAssessmentIdQueryKey(assessmentId);
    const queryFn = ({ signal })=>getBbisResultsAssessment$AssessmentId(assessmentId, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        enabled: !!assessmentId,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetBbisResultsAssessmentAssessmentId(assessmentId, options) {
    _s6();
    const queryOptions = getGetBbisResultsAssessmentAssessmentIdQueryOptions(assessmentId, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s6(useGetBbisResultsAssessmentAssessmentId, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/endpoints/blgu-dashboard/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * // 🚀 Auto-generated by Orval (Axios + React Query)
 * // 🔄 Do not edit manually - regenerate with: pnpm generate-types
 * // 📁 Organized by FastAPI tags for maximum maintainability
 * // 🔐 Uses custom Axios instance with auth & error handling
 * 
 */ __turbopack_context__.s({
    "getBlguDashboard$AssessmentId": (()=>getBlguDashboard$AssessmentId),
    "getBlguDashboard$AssessmentIdIndicatorsNavigation": (()=>getBlguDashboard$AssessmentIdIndicatorsNavigation),
    "getGetBlguDashboardAssessmentIdIndicatorsNavigationQueryKey": (()=>getGetBlguDashboardAssessmentIdIndicatorsNavigationQueryKey),
    "getGetBlguDashboardAssessmentIdIndicatorsNavigationQueryOptions": (()=>getGetBlguDashboardAssessmentIdIndicatorsNavigationQueryOptions),
    "getGetBlguDashboardAssessmentIdQueryKey": (()=>getGetBlguDashboardAssessmentIdQueryKey),
    "getGetBlguDashboardAssessmentIdQueryOptions": (()=>getGetBlguDashboardAssessmentIdQueryOptions),
    "useGetBlguDashboardAssessmentId": (()=>useGetBlguDashboardAssessmentId),
    "useGetBlguDashboardAssessmentIdIndicatorsNavigation": (()=>useGetBlguDashboardAssessmentIdIndicatorsNavigation)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/api.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
const getBlguDashboard$AssessmentId = (assessmentId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/blgu-dashboard/${assessmentId}`,
        method: 'GET',
        signal
    }, options);
};
const getGetBlguDashboardAssessmentIdQueryKey = (assessmentId)=>{
    return [
        `http://localhost:8000/api/v1/blgu-dashboard/${assessmentId}`
    ];
};
const getGetBlguDashboardAssessmentIdQueryOptions = (assessmentId, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetBlguDashboardAssessmentIdQueryKey(assessmentId);
    const queryFn = ({ signal })=>getBlguDashboard$AssessmentId(assessmentId, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        enabled: !!assessmentId,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetBlguDashboardAssessmentId(assessmentId, options) {
    _s();
    const queryOptions = getGetBlguDashboardAssessmentIdQueryOptions(assessmentId, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s(useGetBlguDashboardAssessmentId, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const getBlguDashboard$AssessmentIdIndicatorsNavigation = (assessmentId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/blgu-dashboard/${assessmentId}/indicators/navigation`,
        method: 'GET',
        signal
    }, options);
};
const getGetBlguDashboardAssessmentIdIndicatorsNavigationQueryKey = (assessmentId)=>{
    return [
        `http://localhost:8000/api/v1/blgu-dashboard/${assessmentId}/indicators/navigation`
    ];
};
const getGetBlguDashboardAssessmentIdIndicatorsNavigationQueryOptions = (assessmentId, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetBlguDashboardAssessmentIdIndicatorsNavigationQueryKey(assessmentId);
    const queryFn = ({ signal })=>getBlguDashboard$AssessmentIdIndicatorsNavigation(assessmentId, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        enabled: !!assessmentId,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetBlguDashboardAssessmentIdIndicatorsNavigation(assessmentId, options) {
    _s1();
    const queryOptions = getGetBlguDashboardAssessmentIdIndicatorsNavigationQueryOptions(assessmentId, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s1(useGetBlguDashboardAssessmentIdIndicatorsNavigation, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/endpoints/default/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * // 🚀 Auto-generated by Orval (Axios + React Query)
 * // 🔄 Do not edit manually - regenerate with: pnpm generate-types
 * // 📁 Organized by FastAPI tags for maximum maintainability
 * // 🔐 Uses custom Axios instance with auth & error handling
 * 
 */ __turbopack_context__.s({
    "getGetHealthQueryKey": (()=>getGetHealthQueryKey),
    "getGetHealthQueryOptions": (()=>getGetHealthQueryOptions),
    "getHealth": (()=>getHealth),
    "useGetHealth": (()=>useGetHealth)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/api.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
const getHealth = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/health`,
        method: 'GET',
        signal
    }, options);
};
const getGetHealthQueryKey = ()=>{
    return [
        `http://localhost:8000/health`
    ];
};
const getGetHealthQueryOptions = (options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetHealthQueryKey();
    const queryFn = ({ signal })=>getHealth(requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetHealth(options) {
    _s();
    const queryOptions = getGetHealthQueryOptions(options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s(useGetHealth, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/endpoints/indicators/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * // 🚀 Auto-generated by Orval (Axios + React Query)
 * // 🔄 Do not edit manually - regenerate with: pnpm generate-types
 * // 📁 Organized by FastAPI tags for maximum maintainability
 * // 🔐 Uses custom Axios instance with auth & error handling
 * 
 */ __turbopack_context__.s({
    "deleteIndicators$IndicatorId": (()=>deleteIndicators$IndicatorId),
    "getDeleteIndicatorsIndicatorIdMutationOptions": (()=>getDeleteIndicatorsIndicatorIdMutationOptions),
    "getGetIndicatorsIndicatorIdFormSchemaQueryKey": (()=>getGetIndicatorsIndicatorIdFormSchemaQueryKey),
    "getGetIndicatorsIndicatorIdFormSchemaQueryOptions": (()=>getGetIndicatorsIndicatorIdFormSchemaQueryOptions),
    "getGetIndicatorsIndicatorIdHistoryQueryKey": (()=>getGetIndicatorsIndicatorIdHistoryQueryKey),
    "getGetIndicatorsIndicatorIdHistoryQueryOptions": (()=>getGetIndicatorsIndicatorIdHistoryQueryOptions),
    "getGetIndicatorsIndicatorIdQueryKey": (()=>getGetIndicatorsIndicatorIdQueryKey),
    "getGetIndicatorsIndicatorIdQueryOptions": (()=>getGetIndicatorsIndicatorIdQueryOptions),
    "getGetIndicatorsQueryKey": (()=>getGetIndicatorsQueryKey),
    "getGetIndicatorsQueryOptions": (()=>getGetIndicatorsQueryOptions),
    "getIndicators": (()=>getIndicators),
    "getIndicators$IndicatorId": (()=>getIndicators$IndicatorId),
    "getIndicators$IndicatorIdFormSchema": (()=>getIndicators$IndicatorIdFormSchema),
    "getIndicators$IndicatorIdHistory": (()=>getIndicators$IndicatorIdHistory),
    "getPostIndicatorsMutationOptions": (()=>getPostIndicatorsMutationOptions),
    "getPostIndicatorsTestCalculationMutationOptions": (()=>getPostIndicatorsTestCalculationMutationOptions),
    "getPostIndicatorsValidateCalculationSchemaMutationOptions": (()=>getPostIndicatorsValidateCalculationSchemaMutationOptions),
    "getPostIndicatorsValidateFormSchemaMutationOptions": (()=>getPostIndicatorsValidateFormSchemaMutationOptions),
    "getPutIndicatorsIndicatorIdMutationOptions": (()=>getPutIndicatorsIndicatorIdMutationOptions),
    "postIndicators": (()=>postIndicators),
    "postIndicatorsTestCalculation": (()=>postIndicatorsTestCalculation),
    "postIndicatorsValidateCalculationSchema": (()=>postIndicatorsValidateCalculationSchema),
    "postIndicatorsValidateFormSchema": (()=>postIndicatorsValidateFormSchema),
    "putIndicators$IndicatorId": (()=>putIndicators$IndicatorId),
    "useDeleteIndicatorsIndicatorId": (()=>useDeleteIndicatorsIndicatorId),
    "useGetIndicators": (()=>useGetIndicators),
    "useGetIndicatorsIndicatorId": (()=>useGetIndicatorsIndicatorId),
    "useGetIndicatorsIndicatorIdFormSchema": (()=>useGetIndicatorsIndicatorIdFormSchema),
    "useGetIndicatorsIndicatorIdHistory": (()=>useGetIndicatorsIndicatorIdHistory),
    "usePostIndicators": (()=>usePostIndicators),
    "usePostIndicatorsTestCalculation": (()=>usePostIndicatorsTestCalculation),
    "usePostIndicatorsValidateCalculationSchema": (()=>usePostIndicatorsValidateCalculationSchema),
    "usePostIndicatorsValidateFormSchema": (()=>usePostIndicatorsValidateFormSchema),
    "usePutIndicatorsIndicatorId": (()=>usePutIndicatorsIndicatorId)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/api.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature(), _s7 = __turbopack_context__.k.signature(), _s8 = __turbopack_context__.k.signature(), _s9 = __turbopack_context__.k.signature();
;
;
const postIndicators = (indicatorCreate, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/indicators/`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        data: indicatorCreate,
        signal
    }, options);
};
const getPostIndicatorsMutationOptions = (options)=>{
    const mutationKey = [
        'postIndicators'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { data } = props ?? {};
        return postIndicators(data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostIndicators = (options)=>{
    _s();
    const mutationOptions = getPostIndicatorsMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s(usePostIndicators, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const getIndicators = (params, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/indicators/`,
        method: 'GET',
        params,
        signal
    }, options);
};
const getGetIndicatorsQueryKey = (params)=>{
    return [
        `http://localhost:8000/api/v1/indicators/`,
        ...params ? [
            params
        ] : []
    ];
};
const getGetIndicatorsQueryOptions = (params, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetIndicatorsQueryKey(params);
    const queryFn = ({ signal })=>getIndicators(params, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetIndicators(params, options) {
    _s1();
    const queryOptions = getGetIndicatorsQueryOptions(params, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s1(useGetIndicators, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const postIndicatorsValidateFormSchema = (formSchema, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/indicators/validate-form-schema`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        data: formSchema,
        signal
    }, options);
};
const getPostIndicatorsValidateFormSchemaMutationOptions = (options)=>{
    const mutationKey = [
        'postIndicatorsValidateFormSchema'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { data } = props ?? {};
        return postIndicatorsValidateFormSchema(data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostIndicatorsValidateFormSchema = (options)=>{
    _s2();
    const mutationOptions = getPostIndicatorsValidateFormSchemaMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s2(usePostIndicatorsValidateFormSchema, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const postIndicatorsValidateCalculationSchema = (calculationSchema, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/indicators/validate-calculation-schema`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        data: calculationSchema,
        signal
    }, options);
};
const getPostIndicatorsValidateCalculationSchemaMutationOptions = (options)=>{
    const mutationKey = [
        'postIndicatorsValidateCalculationSchema'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { data } = props ?? {};
        return postIndicatorsValidateCalculationSchema(data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostIndicatorsValidateCalculationSchema = (options)=>{
    _s3();
    const mutationOptions = getPostIndicatorsValidateCalculationSchemaMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s3(usePostIndicatorsValidateCalculationSchema, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const postIndicatorsTestCalculation = (bodyTestCalculationApiV1IndicatorsTestCalculationPost, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/indicators/test-calculation`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        data: bodyTestCalculationApiV1IndicatorsTestCalculationPost,
        signal
    }, options);
};
const getPostIndicatorsTestCalculationMutationOptions = (options)=>{
    const mutationKey = [
        'postIndicatorsTestCalculation'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { data } = props ?? {};
        return postIndicatorsTestCalculation(data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostIndicatorsTestCalculation = (options)=>{
    _s4();
    const mutationOptions = getPostIndicatorsTestCalculationMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s4(usePostIndicatorsTestCalculation, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const getIndicators$IndicatorId = (indicatorId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/indicators/${indicatorId}`,
        method: 'GET',
        signal
    }, options);
};
const getGetIndicatorsIndicatorIdQueryKey = (indicatorId)=>{
    return [
        `http://localhost:8000/api/v1/indicators/${indicatorId}`
    ];
};
const getGetIndicatorsIndicatorIdQueryOptions = (indicatorId, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetIndicatorsIndicatorIdQueryKey(indicatorId);
    const queryFn = ({ signal })=>getIndicators$IndicatorId(indicatorId, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        enabled: !!indicatorId,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetIndicatorsIndicatorId(indicatorId, options) {
    _s5();
    const queryOptions = getGetIndicatorsIndicatorIdQueryOptions(indicatorId, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s5(useGetIndicatorsIndicatorId, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const putIndicators$IndicatorId = (indicatorId, indicatorUpdate, options)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/indicators/${indicatorId}`,
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        data: indicatorUpdate
    }, options);
};
const getPutIndicatorsIndicatorIdMutationOptions = (options)=>{
    const mutationKey = [
        'putIndicatorsIndicatorId'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { indicatorId, data } = props ?? {};
        return putIndicators$IndicatorId(indicatorId, data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePutIndicatorsIndicatorId = (options)=>{
    _s6();
    const mutationOptions = getPutIndicatorsIndicatorIdMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s6(usePutIndicatorsIndicatorId, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const deleteIndicators$IndicatorId = (indicatorId, options)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/indicators/${indicatorId}`,
        method: 'DELETE'
    }, options);
};
const getDeleteIndicatorsIndicatorIdMutationOptions = (options)=>{
    const mutationKey = [
        'deleteIndicatorsIndicatorId'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { indicatorId } = props ?? {};
        return deleteIndicators$IndicatorId(indicatorId, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const useDeleteIndicatorsIndicatorId = (options)=>{
    _s7();
    const mutationOptions = getDeleteIndicatorsIndicatorIdMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s7(useDeleteIndicatorsIndicatorId, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const getIndicators$IndicatorIdHistory = (indicatorId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/indicators/${indicatorId}/history`,
        method: 'GET',
        signal
    }, options);
};
const getGetIndicatorsIndicatorIdHistoryQueryKey = (indicatorId)=>{
    return [
        `http://localhost:8000/api/v1/indicators/${indicatorId}/history`
    ];
};
const getGetIndicatorsIndicatorIdHistoryQueryOptions = (indicatorId, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetIndicatorsIndicatorIdHistoryQueryKey(indicatorId);
    const queryFn = ({ signal })=>getIndicators$IndicatorIdHistory(indicatorId, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        enabled: !!indicatorId,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetIndicatorsIndicatorIdHistory(indicatorId, options) {
    _s8();
    const queryOptions = getGetIndicatorsIndicatorIdHistoryQueryOptions(indicatorId, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s8(useGetIndicatorsIndicatorIdHistory, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const getIndicators$IndicatorIdFormSchema = (indicatorId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/indicators/${indicatorId}/form-schema`,
        method: 'GET',
        signal
    }, options);
};
const getGetIndicatorsIndicatorIdFormSchemaQueryKey = (indicatorId)=>{
    return [
        `http://localhost:8000/api/v1/indicators/${indicatorId}/form-schema`
    ];
};
const getGetIndicatorsIndicatorIdFormSchemaQueryOptions = (indicatorId, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetIndicatorsIndicatorIdFormSchemaQueryKey(indicatorId);
    const queryFn = ({ signal })=>getIndicators$IndicatorIdFormSchema(indicatorId, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        enabled: !!indicatorId,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetIndicatorsIndicatorIdFormSchema(indicatorId, options) {
    _s9();
    const queryOptions = getGetIndicatorsIndicatorIdFormSchemaQueryOptions(indicatorId, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s9(useGetIndicatorsIndicatorIdFormSchema, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/endpoints/lookups/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * // 🚀 Auto-generated by Orval (Axios + React Query)
 * // 🔄 Do not edit manually - regenerate with: pnpm generate-types
 * // 📁 Organized by FastAPI tags for maximum maintainability
 * // 🔐 Uses custom Axios instance with auth & error handling
 * 
 */ __turbopack_context__.s({
    "getGetLookupsBarangaysQueryKey": (()=>getGetLookupsBarangaysQueryKey),
    "getGetLookupsBarangaysQueryOptions": (()=>getGetLookupsBarangaysQueryOptions),
    "getGetLookupsGovernanceAreasQueryKey": (()=>getGetLookupsGovernanceAreasQueryKey),
    "getGetLookupsGovernanceAreasQueryOptions": (()=>getGetLookupsGovernanceAreasQueryOptions),
    "getLookupsBarangays": (()=>getLookupsBarangays),
    "getLookupsGovernanceAreas": (()=>getLookupsGovernanceAreas),
    "useGetLookupsBarangays": (()=>useGetLookupsBarangays),
    "useGetLookupsGovernanceAreas": (()=>useGetLookupsGovernanceAreas)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/api.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
const getLookupsGovernanceAreas = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/lookups/governance-areas`,
        method: 'GET',
        signal
    }, options);
};
const getGetLookupsGovernanceAreasQueryKey = ()=>{
    return [
        `http://localhost:8000/api/v1/lookups/governance-areas`
    ];
};
const getGetLookupsGovernanceAreasQueryOptions = (options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetLookupsGovernanceAreasQueryKey();
    const queryFn = ({ signal })=>getLookupsGovernanceAreas(requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetLookupsGovernanceAreas(options) {
    _s();
    const queryOptions = getGetLookupsGovernanceAreasQueryOptions(options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s(useGetLookupsGovernanceAreas, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const getLookupsBarangays = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/lookups/barangays`,
        method: 'GET',
        signal
    }, options);
};
const getGetLookupsBarangaysQueryKey = ()=>{
    return [
        `http://localhost:8000/api/v1/lookups/barangays`
    ];
};
const getGetLookupsBarangaysQueryOptions = (options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetLookupsBarangaysQueryKey();
    const queryFn = ({ signal })=>getLookupsBarangays(requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetLookupsBarangays(options) {
    _s1();
    const queryOptions = getGetLookupsBarangaysQueryOptions(options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s1(useGetLookupsBarangays, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/endpoints/movs/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * // 🚀 Auto-generated by Orval (Axios + React Query)
 * // 🔄 Do not edit manually - regenerate with: pnpm generate-types
 * // 📁 Organized by FastAPI tags for maximum maintainability
 * // 🔐 Uses custom Axios instance with auth & error handling
 * 
 */ __turbopack_context__.s({
    "deleteMovsFiles$FileId": (()=>deleteMovsFiles$FileId),
    "getDeleteMovsFilesFileIdMutationOptions": (()=>getDeleteMovsFilesFileIdMutationOptions),
    "getGetMovsAssessmentsAssessmentIdIndicatorsIndicatorIdFilesQueryKey": (()=>getGetMovsAssessmentsAssessmentIdIndicatorsIndicatorIdFilesQueryKey),
    "getGetMovsAssessmentsAssessmentIdIndicatorsIndicatorIdFilesQueryOptions": (()=>getGetMovsAssessmentsAssessmentIdIndicatorsIndicatorIdFilesQueryOptions),
    "getMovsAssessments$AssessmentIdIndicators$IndicatorIdFiles": (()=>getMovsAssessments$AssessmentIdIndicators$IndicatorIdFiles),
    "getPostMovsAssessmentsAssessmentIdIndicatorsIndicatorIdUploadMutationOptions": (()=>getPostMovsAssessmentsAssessmentIdIndicatorsIndicatorIdUploadMutationOptions),
    "postMovsAssessments$AssessmentIdIndicators$IndicatorIdUpload": (()=>postMovsAssessments$AssessmentIdIndicators$IndicatorIdUpload),
    "useDeleteMovsFilesFileId": (()=>useDeleteMovsFilesFileId),
    "useGetMovsAssessmentsAssessmentIdIndicatorsIndicatorIdFiles": (()=>useGetMovsAssessmentsAssessmentIdIndicatorsIndicatorIdFiles),
    "usePostMovsAssessmentsAssessmentIdIndicatorsIndicatorIdUpload": (()=>usePostMovsAssessmentsAssessmentIdIndicatorsIndicatorIdUpload)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/api.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
;
;
const postMovsAssessments$AssessmentIdIndicators$IndicatorIdUpload = (assessmentId, indicatorId, bodyUploadMovFileApiV1MovsAssessmentsAssessmentIdIndicatorsIndicatorIdUploadPost, options, signal)=>{
    const formData = new FormData();
    formData.append(`file`, bodyUploadMovFileApiV1MovsAssessmentsAssessmentIdIndicatorsIndicatorIdUploadPost.file);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/movs/assessments/${assessmentId}/indicators/${indicatorId}/upload`,
        method: 'POST',
        headers: {
            'Content-Type': 'multipart/form-data'
        },
        data: formData,
        signal
    }, options);
};
const getPostMovsAssessmentsAssessmentIdIndicatorsIndicatorIdUploadMutationOptions = (options)=>{
    const mutationKey = [
        'postMovsAssessmentsAssessmentIdIndicatorsIndicatorIdUpload'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { assessmentId, indicatorId, data } = props ?? {};
        return postMovsAssessments$AssessmentIdIndicators$IndicatorIdUpload(assessmentId, indicatorId, data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostMovsAssessmentsAssessmentIdIndicatorsIndicatorIdUpload = (options)=>{
    _s();
    const mutationOptions = getPostMovsAssessmentsAssessmentIdIndicatorsIndicatorIdUploadMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s(usePostMovsAssessmentsAssessmentIdIndicatorsIndicatorIdUpload, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const getMovsAssessments$AssessmentIdIndicators$IndicatorIdFiles = (assessmentId, indicatorId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/movs/assessments/${assessmentId}/indicators/${indicatorId}/files`,
        method: 'GET',
        signal
    }, options);
};
const getGetMovsAssessmentsAssessmentIdIndicatorsIndicatorIdFilesQueryKey = (assessmentId, indicatorId)=>{
    return [
        `http://localhost:8000/api/v1/movs/assessments/${assessmentId}/indicators/${indicatorId}/files`
    ];
};
const getGetMovsAssessmentsAssessmentIdIndicatorsIndicatorIdFilesQueryOptions = (assessmentId, indicatorId, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetMovsAssessmentsAssessmentIdIndicatorsIndicatorIdFilesQueryKey(assessmentId, indicatorId);
    const queryFn = ({ signal })=>getMovsAssessments$AssessmentIdIndicators$IndicatorIdFiles(assessmentId, indicatorId, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        enabled: !!(assessmentId && indicatorId),
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetMovsAssessmentsAssessmentIdIndicatorsIndicatorIdFiles(assessmentId, indicatorId, options) {
    _s1();
    const queryOptions = getGetMovsAssessmentsAssessmentIdIndicatorsIndicatorIdFilesQueryOptions(assessmentId, indicatorId, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s1(useGetMovsAssessmentsAssessmentIdIndicatorsIndicatorIdFiles, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const deleteMovsFiles$FileId = (fileId, options)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/movs/files/${fileId}`,
        method: 'DELETE'
    }, options);
};
const getDeleteMovsFilesFileIdMutationOptions = (options)=>{
    const mutationKey = [
        'deleteMovsFilesFileId'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { fileId } = props ?? {};
        return deleteMovsFiles$FileId(fileId, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const useDeleteMovsFilesFileId = (options)=>{
    _s2();
    const mutationOptions = getDeleteMovsFilesFileIdMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s2(useDeleteMovsFilesFileId, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/endpoints/system/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * // 🚀 Auto-generated by Orval (Axios + React Query)
 * // 🔄 Do not edit manually - regenerate with: pnpm generate-types
 * // 📁 Organized by FastAPI tags for maximum maintainability
 * // 🔐 Uses custom Axios instance with auth & error handling
 * 
 */ __turbopack_context__.s({
    "getGetSystemDbStatusQueryKey": (()=>getGetSystemDbStatusQueryKey),
    "getGetSystemDbStatusQueryOptions": (()=>getGetSystemDbStatusQueryOptions),
    "getGetSystemHealthQueryKey": (()=>getGetSystemHealthQueryKey),
    "getGetSystemHealthQueryOptions": (()=>getGetSystemHealthQueryOptions),
    "getGetSystemHelloQueryKey": (()=>getGetSystemHelloQueryKey),
    "getGetSystemHelloQueryOptions": (()=>getGetSystemHelloQueryOptions),
    "getGetSystemQueryKey": (()=>getGetSystemQueryKey),
    "getGetSystemQueryOptions": (()=>getGetSystemQueryOptions),
    "getSystem": (()=>getSystem),
    "getSystemDbStatus": (()=>getSystemDbStatus),
    "getSystemHealth": (()=>getSystemHealth),
    "getSystemHello": (()=>getSystemHello),
    "useGetSystem": (()=>useGetSystem),
    "useGetSystemDbStatus": (()=>useGetSystemDbStatus),
    "useGetSystemHealth": (()=>useGetSystemHealth),
    "useGetSystemHello": (()=>useGetSystemHello)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/api.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
;
;
const getSystem = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/system/`,
        method: 'GET',
        signal
    }, options);
};
const getGetSystemQueryKey = ()=>{
    return [
        `http://localhost:8000/api/v1/system/`
    ];
};
const getGetSystemQueryOptions = (options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetSystemQueryKey();
    const queryFn = ({ signal })=>getSystem(requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetSystem(options) {
    _s();
    const queryOptions = getGetSystemQueryOptions(options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s(useGetSystem, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const getSystemHealth = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/system/health`,
        method: 'GET',
        signal
    }, options);
};
const getGetSystemHealthQueryKey = ()=>{
    return [
        `http://localhost:8000/api/v1/system/health`
    ];
};
const getGetSystemHealthQueryOptions = (options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetSystemHealthQueryKey();
    const queryFn = ({ signal })=>getSystemHealth(requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetSystemHealth(options) {
    _s1();
    const queryOptions = getGetSystemHealthQueryOptions(options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s1(useGetSystemHealth, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const getSystemDbStatus = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/system/db-status`,
        method: 'GET',
        signal
    }, options);
};
const getGetSystemDbStatusQueryKey = ()=>{
    return [
        `http://localhost:8000/api/v1/system/db-status`
    ];
};
const getGetSystemDbStatusQueryOptions = (options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetSystemDbStatusQueryKey();
    const queryFn = ({ signal })=>getSystemDbStatus(requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetSystemDbStatus(options) {
    _s2();
    const queryOptions = getGetSystemDbStatusQueryOptions(options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s2(useGetSystemDbStatus, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const getSystemHello = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/system/hello`,
        method: 'GET',
        signal
    }, options);
};
const getGetSystemHelloQueryKey = ()=>{
    return [
        `http://localhost:8000/api/v1/system/hello`
    ];
};
const getGetSystemHelloQueryOptions = (options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetSystemHelloQueryKey();
    const queryFn = ({ signal })=>getSystemHello(requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetSystemHello(options) {
    _s3();
    const queryOptions = getGetSystemHelloQueryOptions(options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s3(useGetSystemHello, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/endpoints/users/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * // 🚀 Auto-generated by Orval (Axios + React Query)
 * // 🔄 Do not edit manually - regenerate with: pnpm generate-types
 * // 📁 Organized by FastAPI tags for maximum maintainability
 * // 🔐 Uses custom Axios instance with auth & error handling
 * 
 */ __turbopack_context__.s({
    "deleteUsers$UserId": (()=>deleteUsers$UserId),
    "getDeleteUsersUserIdMutationOptions": (()=>getDeleteUsersUserIdMutationOptions),
    "getGetUsersMeQueryKey": (()=>getGetUsersMeQueryKey),
    "getGetUsersMeQueryOptions": (()=>getGetUsersMeQueryOptions),
    "getGetUsersQueryKey": (()=>getGetUsersQueryKey),
    "getGetUsersQueryOptions": (()=>getGetUsersQueryOptions),
    "getGetUsersStatsDashboardQueryKey": (()=>getGetUsersStatsDashboardQueryKey),
    "getGetUsersStatsDashboardQueryOptions": (()=>getGetUsersStatsDashboardQueryOptions),
    "getGetUsersUserIdQueryKey": (()=>getGetUsersUserIdQueryKey),
    "getGetUsersUserIdQueryOptions": (()=>getGetUsersUserIdQueryOptions),
    "getPostUsersMutationOptions": (()=>getPostUsersMutationOptions),
    "getPostUsersUserIdActivateMutationOptions": (()=>getPostUsersUserIdActivateMutationOptions),
    "getPostUsersUserIdResetPasswordMutationOptions": (()=>getPostUsersUserIdResetPasswordMutationOptions),
    "getPutUsersMeMutationOptions": (()=>getPutUsersMeMutationOptions),
    "getPutUsersUserIdMutationOptions": (()=>getPutUsersUserIdMutationOptions),
    "getUsers": (()=>getUsers),
    "getUsers$UserId": (()=>getUsers$UserId),
    "getUsersMe": (()=>getUsersMe),
    "getUsersStatsDashboard": (()=>getUsersStatsDashboard),
    "postUsers": (()=>postUsers),
    "postUsers$UserIdActivate": (()=>postUsers$UserIdActivate),
    "postUsers$UserIdResetPassword": (()=>postUsers$UserIdResetPassword),
    "putUsers$UserId": (()=>putUsers$UserId),
    "putUsersMe": (()=>putUsersMe),
    "useDeleteUsersUserId": (()=>useDeleteUsersUserId),
    "useGetUsers": (()=>useGetUsers),
    "useGetUsersMe": (()=>useGetUsersMe),
    "useGetUsersStatsDashboard": (()=>useGetUsersStatsDashboard),
    "useGetUsersUserId": (()=>useGetUsersUserId),
    "usePostUsers": (()=>usePostUsers),
    "usePostUsersUserIdActivate": (()=>usePostUsersUserIdActivate),
    "usePostUsersUserIdResetPassword": (()=>usePostUsersUserIdResetPassword),
    "usePutUsersMe": (()=>usePutUsersMe),
    "usePutUsersUserId": (()=>usePutUsersUserId)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.80.7_react@19.1.0/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/api.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature(), _s7 = __turbopack_context__.k.signature(), _s8 = __turbopack_context__.k.signature(), _s9 = __turbopack_context__.k.signature();
;
;
const getUsersMe = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/users/me`,
        method: 'GET',
        signal
    }, options);
};
const getGetUsersMeQueryKey = ()=>{
    return [
        `http://localhost:8000/api/v1/users/me`
    ];
};
const getGetUsersMeQueryOptions = (options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetUsersMeQueryKey();
    const queryFn = ({ signal })=>getUsersMe(requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetUsersMe(options) {
    _s();
    const queryOptions = getGetUsersMeQueryOptions(options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s(useGetUsersMe, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const putUsersMe = (userUpdate, options)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/users/me`,
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        data: userUpdate
    }, options);
};
const getPutUsersMeMutationOptions = (options)=>{
    const mutationKey = [
        'putUsersMe'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { data } = props ?? {};
        return putUsersMe(data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePutUsersMe = (options)=>{
    _s1();
    const mutationOptions = getPutUsersMeMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s1(usePutUsersMe, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const getUsers = (params, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/users/`,
        method: 'GET',
        params,
        signal
    }, options);
};
const getGetUsersQueryKey = (params)=>{
    return [
        `http://localhost:8000/api/v1/users/`,
        ...params ? [
            params
        ] : []
    ];
};
const getGetUsersQueryOptions = (params, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetUsersQueryKey(params);
    const queryFn = ({ signal })=>getUsers(params, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetUsers(params, options) {
    _s2();
    const queryOptions = getGetUsersQueryOptions(params, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s2(useGetUsers, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const postUsers = (userAdminCreate, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/users/`,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        data: userAdminCreate,
        signal
    }, options);
};
const getPostUsersMutationOptions = (options)=>{
    const mutationKey = [
        'postUsers'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { data } = props ?? {};
        return postUsers(data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostUsers = (options)=>{
    _s3();
    const mutationOptions = getPostUsersMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s3(usePostUsers, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const getUsers$UserId = (userId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/users/${userId}`,
        method: 'GET',
        signal
    }, options);
};
const getGetUsersUserIdQueryKey = (userId)=>{
    return [
        `http://localhost:8000/api/v1/users/${userId}`
    ];
};
const getGetUsersUserIdQueryOptions = (userId, options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetUsersUserIdQueryKey(userId);
    const queryFn = ({ signal })=>getUsers$UserId(userId, requestOptions, signal);
    return {
        queryKey,
        queryFn,
        enabled: !!userId,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetUsersUserId(userId, options) {
    _s4();
    const queryOptions = getGetUsersUserIdQueryOptions(userId, options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s4(useGetUsersUserId, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const putUsers$UserId = (userId, userAdminUpdate, options)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/users/${userId}`,
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        data: userAdminUpdate
    }, options);
};
const getPutUsersUserIdMutationOptions = (options)=>{
    const mutationKey = [
        'putUsersUserId'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { userId, data } = props ?? {};
        return putUsers$UserId(userId, data, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePutUsersUserId = (options)=>{
    _s5();
    const mutationOptions = getPutUsersUserIdMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s5(usePutUsersUserId, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const deleteUsers$UserId = (userId, options)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/users/${userId}`,
        method: 'DELETE'
    }, options);
};
const getDeleteUsersUserIdMutationOptions = (options)=>{
    const mutationKey = [
        'deleteUsersUserId'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { userId } = props ?? {};
        return deleteUsers$UserId(userId, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const useDeleteUsersUserId = (options)=>{
    _s6();
    const mutationOptions = getDeleteUsersUserIdMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s6(useDeleteUsersUserId, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const postUsers$UserIdActivate = (userId, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/users/${userId}/activate`,
        method: 'POST',
        signal
    }, options);
};
const getPostUsersUserIdActivateMutationOptions = (options)=>{
    const mutationKey = [
        'postUsersUserIdActivate'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { userId } = props ?? {};
        return postUsers$UserIdActivate(userId, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostUsersUserIdActivate = (options)=>{
    _s7();
    const mutationOptions = getPostUsersUserIdActivateMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s7(usePostUsersUserIdActivate, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const postUsers$UserIdResetPassword = (userId, params, options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/users/${userId}/reset-password`,
        method: 'POST',
        params,
        signal
    }, options);
};
const getPostUsersUserIdResetPasswordMutationOptions = (options)=>{
    const mutationKey = [
        'postUsersUserIdResetPassword'
    ];
    const { mutation: mutationOptions, request: requestOptions } = options ? options.mutation && 'mutationKey' in options.mutation && options.mutation.mutationKey ? options : {
        ...options,
        mutation: {
            ...options.mutation,
            mutationKey
        }
    } : {
        mutation: {
            mutationKey
        },
        request: undefined
    };
    const mutationFn = (props)=>{
        const { userId, params } = props ?? {};
        return postUsers$UserIdResetPassword(userId, params, requestOptions);
    };
    return {
        mutationFn,
        ...mutationOptions
    };
};
const usePostUsersUserIdResetPassword = (options)=>{
    _s8();
    const mutationOptions = getPostUsersUserIdResetPasswordMutationOptions(options);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutationOptions);
};
_s8(usePostUsersUserIdResetPassword, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const getUsersStatsDashboard = (options, signal)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mutator"])({
        url: `http://localhost:8000/api/v1/users/stats/dashboard`,
        method: 'GET',
        signal
    }, options);
};
const getGetUsersStatsDashboardQueryKey = ()=>{
    return [
        `http://localhost:8000/api/v1/users/stats/dashboard`
    ];
};
const getGetUsersStatsDashboardQueryOptions = (options)=>{
    const { query: queryOptions, request: requestOptions } = options ?? {};
    const queryKey = queryOptions?.queryKey ?? getGetUsersStatsDashboardQueryKey();
    const queryFn = ({ signal })=>getUsersStatsDashboard(requestOptions, signal);
    return {
        queryKey,
        queryFn,
        staleTime: 300000,
        refetchOnWindowFocus: false,
        ...queryOptions
    };
};
function useGetUsersStatsDashboard(options) {
    _s9();
    const queryOptions = getGetUsersStatsDashboardQueryOptions(options);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(queryOptions);
    query.queryKey = queryOptions.queryKey;
    return query;
}
_s9(useGetUsersStatsDashboard, "c7fxJWDO4uMGjIdKMJSj1aiS9wg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$80$2e$7_react$40$19$2e$1$2e$0$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/endpoints/index.ts [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Barrel file for all endpoint modules.
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$admin$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/admin/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$analytics$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/analytics/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$assessments$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/assessments/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$assessor$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/assessor/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$auth$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/auth/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$bbis$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/bbis/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$blgu$2d$dashboard$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/blgu-dashboard/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$default$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/default/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$indicators$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/indicators/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$lookups$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/lookups/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$movs$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/movs/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$system$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/system/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$users$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/users/index.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/endpoints/index.ts [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$admin$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/admin/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$analytics$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/analytics/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$assessments$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/assessments/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$assessor$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/assessor/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$auth$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/auth/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$bbis$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/bbis/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$blgu$2d$dashboard$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/blgu-dashboard/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$default$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/default/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$indicators$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/indicators/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$lookups$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/lookups/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$movs$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/movs/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$system$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/system/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$users$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/users/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/index.ts [app-client] (ecmascript) <locals>");
}}),
"[project]/packages/shared/src/generated/schemas/auth/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Auth-related types
// 🏷️  Based on FastAPI tag: "auth"
/**
 * AuthToken
 */ __turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/assessments/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Assessments-related types
// 🏷️  Based on FastAPI tag: "assessments"
__turbopack_context__.s({
    "AssessmentStatus": (()=>AssessmentStatus)
});
const AssessmentStatus = {
    Draft: 'Draft',
    Submitted_for_Review: 'Submitted for Review',
    Validated: 'Validated',
    Needs_Rework: 'Needs Rework'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/users/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Users-related types
// 🏷️  Based on FastAPI tag: "users"
/**
 * AuditLogResponseUserEmail
 */ __turbopack_context__.s({
    "UserRole": (()=>UserRole)
});
const UserRole = {
    MLGOO_DILG: 'MLGOO_DILG',
    ASSESSOR: 'ASSESSOR',
    VALIDATOR: 'VALIDATOR',
    BLGU_USER: 'BLGU_USER'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/system/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 System-related types
// 🏷️  Based on FastAPI tag: "system"
__turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/assessor/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Assessor-related types
// 🏷️  Based on FastAPI tag: "assessor"
__turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/analytics/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Analytics-related types
// 🏷️  Based on FastAPI tag: "analytics"
/**
 * GetAnalyticsDashboardParams
 */ __turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/admin/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Admin-related types
// 🏷️  Based on FastAPI tag: "admin"
/**
 * AdminSuccessResponse
 */ __turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/indicators/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Indicators-related types
// 🏷️  Based on FastAPI tag: "indicators"
__turbopack_context__.s({
    "IndicatorNavigationItemCompletionStatus": (()=>IndicatorNavigationItemCompletionStatus)
});
const IndicatorNavigationItemCompletionStatus = {
    complete: 'complete',
    incomplete: 'incomplete'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/bbis/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Bbis-related types
// 🏷️  Based on FastAPI tag: "bbis"
__turbopack_context__.s({
    "BBIFunctionalityCheckRuleExpectedStatus": (()=>BBIFunctionalityCheckRuleExpectedStatus),
    "BBIStatus": (()=>BBIStatus)
});
const BBIFunctionalityCheckRuleExpectedStatus = {
    Functional: 'Functional',
    'Non-Functional': 'Non-Functional'
};
const BBIStatus = {
    FUNCTIONAL: 'FUNCTIONAL',
    NON_FUNCTIONAL: 'NON_FUNCTIONAL'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/movs/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Movs-related types
// 🏷️  Based on FastAPI tag: "movs"
/**
 * ConditionalMOVLogic
 */ __turbopack_context__.s({
    "ConditionalMOVLogicOperator": (()=>ConditionalMOVLogicOperator),
    "MOVStatus": (()=>MOVStatus)
});
const ConditionalMOVLogicOperator = {
    equals: 'equals',
    not_equals: 'not_equals'
};
const MOVStatus = {
    Pending: 'Pending',
    Uploaded: 'Uploaded',
    Deleted: 'Deleted'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/andallrule/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Andallrule-related types
// 🏷️  Based on FastAPI tag: "andallrule"
__turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/countthresholdrule/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Countthresholdrule-related types
// 🏷️  Based on FastAPI tag: "countthresholdrule"
__turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/deadlineoverride/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Deadlineoverride-related types
// 🏷️  Based on FastAPI tag: "deadlineoverride"
__turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/formschema/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Formschema-related types
// 🏷️  Based on FastAPI tag: "formschema"
__turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/formschemametadata/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Formschemametadata-related types
// 🏷️  Based on FastAPI tag: "formschemametadata"
__turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/governancearea/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Governancearea-related types
// 🏷️  Based on FastAPI tag: "governancearea"
__turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/matchvaluerule/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Matchvaluerule-related types
// 🏷️  Based on FastAPI tag: "matchvaluerule"
__turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/oranyrule/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Oranyrule-related types
// 🏷️  Based on FastAPI tag: "oranyrule"
__turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/percentagethresholdrule/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Percentagethresholdrule-related types
// 🏷️  Based on FastAPI tag: "percentagethresholdrule"
__turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/saveanswers/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Saveanswers-related types
// 🏷️  Based on FastAPI tag: "saveanswers"
__turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/validation/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Validation-related types
// 🏷️  Based on FastAPI tag: "validation"
__turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/error/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Error-related types
// 🏷️  Based on FastAPI tag: "error"
/**
 * HTTPValidationError
 */ __turbopack_context__.s({
    "ValidationStatus": (()=>ValidationStatus)
});
const ValidationStatus = {
    Pass: 'Pass',
    Fail: 'Fail',
    Conditional: 'Conditional'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/common/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Common-related types
// 🏷️  Based on FastAPI tag: "common"
__turbopack_context__.s({
    "AreaType": (()=>AreaType),
    "CalculationSchemaOutputStatusOnFail": (()=>CalculationSchemaOutputStatusOnFail),
    "CalculationSchemaOutputStatusOnPass": (()=>CalculationSchemaOutputStatusOnPass),
    "ConditionGroupOperator": (()=>ConditionGroupOperator),
    "CountThresholdRuleOperator": (()=>CountThresholdRuleOperator),
    "MatchValueRuleOperator": (()=>MatchValueRuleOperator),
    "PercentageThresholdRuleOperator": (()=>PercentageThresholdRuleOperator)
});
const AreaType = {
    Core: 'Core',
    Essential: 'Essential'
};
const CalculationSchemaOutputStatusOnFail = {
    Pass: 'Pass',
    Fail: 'Fail'
};
const CalculationSchemaOutputStatusOnPass = {
    Pass: 'Pass',
    Fail: 'Fail'
};
const ConditionGroupOperator = {
    AND: 'AND',
    OR: 'OR'
};
const CountThresholdRuleOperator = {
    '>=': '>=',
    '>': '>',
    '<=': '<=',
    '<': '<',
    '==': '=='
};
const MatchValueRuleOperator = {
    '==': '==',
    '!=': '!=',
    contains: 'contains',
    not_contains: 'not_contains'
};
const PercentageThresholdRuleOperator = {
    '>=': '>=',
    '>': '>',
    '<=': '<=',
    '<': '<',
    '==': '=='
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/index.ts [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval (Grouped by FastAPI Tags)
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Organized by FastAPI tags for maximum maintainability
// 🏷️  Groups: auth, assessments, users, system, assessor, analytics, admin, indicators, bbis, movs, andallrule, countthresholdrule, deadlineoverride, formschema, formschemametadata, governancearea, matchvaluerule, oranyrule, percentagethresholdrule, saveanswers, validation, error, common
// Export all grouped schema modules
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$auth$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/auth/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$assessments$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/assessments/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$users$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/users/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$system$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/system/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$assessor$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/assessor/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$analytics$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/analytics/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$admin$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/admin/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$indicators$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/indicators/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$bbis$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/bbis/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$movs$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/movs/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$andallrule$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/andallrule/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$countthresholdrule$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/countthresholdrule/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$deadlineoverride$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/deadlineoverride/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$formschema$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/formschema/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$formschemametadata$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/formschemametadata/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$governancearea$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/governancearea/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$matchvaluerule$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/matchvaluerule/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$oranyrule$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/oranyrule/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$percentagethresholdrule$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/percentagethresholdrule/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$saveanswers$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/saveanswers/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$validation$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/validation/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$error$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/error/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$common$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/common/index.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/schemas/index.ts [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$auth$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/auth/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$assessments$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/assessments/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$users$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/users/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$system$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/system/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$assessor$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/assessor/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$analytics$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/analytics/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$admin$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/admin/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$indicators$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/indicators/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$bbis$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/bbis/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$movs$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/movs/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$andallrule$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/andallrule/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$countthresholdrule$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/countthresholdrule/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$deadlineoverride$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/deadlineoverride/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$formschema$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/formschema/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$formschemametadata$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/formschemametadata/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$governancearea$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/governancearea/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$matchvaluerule$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/matchvaluerule/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$oranyrule$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/oranyrule/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$percentagethresholdrule$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/percentagethresholdrule/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$saveanswers$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/saveanswers/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$validation$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/validation/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$error$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/error/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$common$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/common/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/index.ts [app-client] (ecmascript) <locals>");
}}),
"[project]/packages/shared/src/generated/index.ts [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Auto-generated by Orval
// 🔄 Do not edit manually - regenerate with: pnpm generate-types
// 📁 Main barrel file for the generated client.
// 📦 Export all endpoint modules
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/index.ts [app-client] (ecmascript) <module evaluation>");
// 📝 Export all schema modules
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/index.ts [app-client] (ecmascript) <module evaluation>");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/shared/src/generated/index.ts [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/index.ts [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$schemas$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/schemas/index.ts [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/index.ts [app-client] (ecmascript) <locals>");
}}),
"[project]/apps/web/src/components/features/auth/LoginForm.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 🚀 Modern login form using auto-generated React Query hooks
__turbopack_context__.s({
    "default": (()=>LoginForm)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.3_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$ui$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/components/ui/Skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$store$2f$useAuthStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/store/useAuthStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/index.ts [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$users$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/users/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$auth$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/shared/src/generated/endpoints/auth/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$515$2e$0_react$40$19$2e$1$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.515.0_react@19.1.0/node_modules/lucide-react/dist/esm/icons/eye.js [app-client] (ecmascript) <export default as Eye>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$515$2e$0_react$40$19$2e$1$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeOff$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.515.0_react@19.1.0/node_modules/lucide-react/dist/esm/icons/eye-off.js [app-client] (ecmascript) <export default as EyeOff>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$515$2e$0_react$40$19$2e$1$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Lock$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.515.0_react@19.1.0/node_modules/lucide-react/dist/esm/icons/lock.js [app-client] (ecmascript) <export default as Lock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$515$2e$0_react$40$19$2e$1$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.515.0_react@19.1.0/node_modules/lucide-react/dist/esm/icons/mail.js [app-client] (ecmascript) <export default as Mail>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.3_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.3_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$hot$2d$toast$40$2$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-hot-toast@2.5.2_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/react-hot-toast/dist/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
function LoginForm({ isDarkMode = false }) {
    _s();
    const [email, setEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [password, setPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [showPassword, setShowPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isCapsLockOn, setIsCapsLockOn] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [rememberMe, setRememberMe] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [shouldFetchUser, setShouldFetchUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLoaded, setIsLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [loginSuccess, setLoginSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    // Small entrance animation
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LoginForm.useEffect": ()=>{
            const timer = setTimeout({
                "LoginForm.useEffect.timer": ()=>{
                    setIsLoaded(true);
                }
            }["LoginForm.useEffect.timer"], 150);
            return ({
                "LoginForm.useEffect": ()=>clearTimeout(timer)
            })["LoginForm.useEffect"];
        }
    }["LoginForm.useEffect"], []);
    // Prevent any form submission on the page
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LoginForm.useEffect": ()=>{
            const preventFormSubmit = {
                "LoginForm.useEffect.preventFormSubmit": (e)=>{
                    if (e.type === "submit") {
                        console.log("Global form submit prevented");
                        e.preventDefault();
                        e.stopPropagation();
                        return false;
                    }
                }
            }["LoginForm.useEffect.preventFormSubmit"];
            document.addEventListener("submit", preventFormSubmit, true);
            return ({
                "LoginForm.useEffect": ()=>{
                    document.removeEventListener("submit", preventFormSubmit, true);
                }
            })["LoginForm.useEffect"];
        }
    }["LoginForm.useEffect"], []);
    // Get auth store actions
    const { setToken, setUser } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$store$2f$useAuthStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"])();
    // Auto-generated login mutation hook
    const loginMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$auth$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePostAuthLogin"])({
        mutation: {
            onSuccess: {
                "LoginForm.usePostAuthLogin[loginMutation]": (response)=>{
                    console.log("Login successful:", response);
                    // Extract token from response
                    const accessToken = response.access_token;
                    if (!accessToken) {
                        console.error("No access token received from server");
                        return;
                    }
                    // Store token in auth store
                    setToken(accessToken);
                    setLoginSuccess(true);
                    // Show success message with animation
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$hot$2d$toast$40$2$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].success("🎉 Welcome back! Redirecting to your dashboard...", {
                        duration: 3000,
                        style: {
                            background: isDarkMode ? "#1f2937" : "#ffffff",
                            color: isDarkMode ? "#ffffff" : "#1f2937",
                            border: `1px solid ${isDarkMode ? "#fbbf24" : "#f59e0b"}`,
                            borderRadius: "12px",
                            padding: "16px",
                            fontSize: "14px",
                            fontWeight: "500"
                        }
                    });
                    // Trigger user data fetch
                    setShouldFetchUser(true);
                }
            }["LoginForm.usePostAuthLogin[loginMutation]"],
            onError: {
                "LoginForm.usePostAuthLogin[loginMutation]": (error)=>{
                    console.error("Login failed:", error);
                    console.log("Error type:", typeof error);
                    console.log("Error details:", error);
                    // Show error toast with specific message
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$hot$2d$toast$40$2$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].error("Wrong email or password", {
                        duration: 3000,
                        style: {
                            background: isDarkMode ? "#1f2937" : "#ffffff",
                            color: isDarkMode ? "#ffffff" : "#1f2937",
                            border: "1px solid #ef4444",
                            borderRadius: "12px",
                            padding: "16px",
                            fontSize: "14px",
                            fontWeight: "500"
                        }
                    });
                // Error handled successfully - no navigation needed
                }
            }["LoginForm.usePostAuthLogin[loginMutation]"],
            retry: false,
            onSettled: {
                "LoginForm.usePostAuthLogin[loginMutation]": (data, error)=>{
                    console.log("Mutation settled - Data:", data, "Error:", error);
                    if (error) {
                        console.log("Error in onSettled:", error);
                    }
                }
            }["LoginForm.usePostAuthLogin[loginMutation]"]
        }
    });
    // Auto-generated hook to fetch current user data
    const userQuery = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$users$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetUsersMe"])();
    // Handle user data fetch success/error
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LoginForm.useEffect": ()=>{
            if (shouldFetchUser) {
                // Trigger user data fetch
                userQuery.refetch().then({
                    "LoginForm.useEffect": (result)=>{
                        if (result.data) {
                            console.log("User data fetched:", result.data);
                            // Store user in auth store
                            setUser(result.data);
                            // Check for redirect parameter first, then fall back to dashboard
                            const redirectTo = searchParams.get("redirect");
                            let targetPath;
                            if (redirectTo) {
                                // Validate the redirect path to prevent open redirects
                                const isValidRedirect = redirectTo.startsWith("/blgu/") || redirectTo.startsWith("/mlgoo/") || redirectTo.startsWith("/assessor/") || redirectTo.startsWith("/validator/") || redirectTo.startsWith("/user-management/") || redirectTo.startsWith("/change-password");
                                if (isValidRedirect) {
                                    targetPath = redirectTo;
                                } else {
                                    // Fall back to dashboard if redirect is invalid
                                    const isAdmin = result.data.role === "MLGOO_DILG";
                                    const isAssessor = result.data.role === "ASSESSOR";
                                    const isValidator = result.data.role === "VALIDATOR";
                                    if (isAdmin) {
                                        targetPath = "/mlgoo/dashboard";
                                    } else if (isAssessor) {
                                        targetPath = "/assessor/submissions";
                                    } else if (isValidator) {
                                        targetPath = "/validator/submissions";
                                    } else {
                                        targetPath = "/blgu/dashboard";
                                    }
                                }
                            } else {
                                // No redirect parameter, go to appropriate dashboard
                                console.log("LoginForm: No redirect parameter, determining dashboard based on role");
                                console.log("LoginForm: User data:", result.data);
                                console.log("LoginForm: User role:", result.data.role);
                                const isAdmin = result.data.role === "MLGOO_DILG";
                                const isAssessor = result.data.role === "ASSESSOR";
                                const isValidator = result.data.role === "VALIDATOR";
                                console.log("LoginForm: Role checks:", {
                                    isAdmin,
                                    isAssessor,
                                    isValidator
                                });
                                if (isAdmin) {
                                    targetPath = "/mlgoo/dashboard";
                                } else if (isAssessor) {
                                    targetPath = "/assessor/submissions";
                                } else if (isValidator) {
                                    targetPath = "/validator/submissions";
                                } else {
                                    targetPath = "/blgu/dashboard";
                                }
                                console.log("LoginForm: Determined target path:", targetPath);
                            }
                            console.log("LoginForm: Navigating to:", targetPath);
                            router.replace(targetPath);
                        } else if (result.error) {
                            console.error("Failed to fetch user data:", result.error);
                            // Even if user fetch fails, we can still redirect to dashboard
                            // Since we don't have user data, redirect to login to be safe
                            router.replace("/login");
                        }
                        // Reset the flag
                        setShouldFetchUser(false);
                    }
                }["LoginForm.useEffect"]);
            }
        }
    }["LoginForm.useEffect"], [
        shouldFetchUser,
        userQuery,
        setUser,
        router,
        searchParams
    ]);
    // Show toast on login success
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LoginForm.useEffect": ()=>{
            if (loginMutation.isSuccess) {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$hot$2d$toast$40$2$2e$5$2e$2_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].success("Login Successfully");
            }
        }
    }["LoginForm.useEffect"], [
        loginMutation.isSuccess
    ]);
    const handleSubmit = (e)=>{
        console.log("Submit triggered", e.type);
        e.preventDefault();
        e.stopPropagation();
        // Additional prevention for any potential form submission
        if (e.type === "submit") {
            e.preventDefault();
            e.stopPropagation();
            return false;
        }
        const credentials = {
            email,
            password
        };
        console.log("Submitting credentials:", credentials);
        // Use regular mutate instead of mutateAsync to prevent form refresh
        try {
            loginMutation.mutate({
                data: credentials
            });
        } catch (error) {
            console.error("Mutation error caught:", error);
        // Error should be handled by onError callback
        }
        // Return false to prevent any default behavior
        return false;
    };
    // Get error message for display
    const getErrorMessage = ()=>{
        if (!loginMutation.error) return null;
        // Handle different error types
        if (loginMutation.error instanceof Error) {
            // Check if it's a 401 error and provide user-friendly message
            if (loginMutation.error.message.includes("401")) {
                return "Incorrect email or password. Please try again.";
            }
            return loginMutation.error.message;
        }
        // Handle API error responses
        if (typeof loginMutation.error === "object" && loginMutation.error !== null) {
            const apiError = loginMutation.error;
            // Check for 401 status code
            if (apiError.response?.status === 401) {
                return "Incorrect email or password. Please try again.";
            }
            if (apiError.response?.data?.detail) {
                return apiError.response.data.detail;
            }
            if (apiError.message) {
                return apiError.message;
            }
        }
        return "Incorrect email or password. Please try again.";
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4",
        children: Boolean(loginMutation.isPending) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: `transition-colors duration-200`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                            className: `block text-sm font-medium mb-2 transition-colors duration-500 ${isDarkMode ? "text-gray-300" : "text-gray-700"}`,
                            children: "Email"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                            lineNumber: 298,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$ui$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Skeleton"], {
                            shape: "rounded",
                            size: "lg",
                            width: "full",
                            className: "mb-2"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                            lineNumber: 305,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                    lineNumber: 297,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: `mt-4`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                            className: `block text-sm font-medium mb-2 transition-colors duration-500 ${isDarkMode ? "text-gray-300" : "text-gray-700"}`,
                            children: "Password"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                            lineNumber: 308,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$ui$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Skeleton"], {
                            shape: "rounded",
                            size: "lg",
                            width: "full",
                            className: "mb-2"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                            lineNumber: 315,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                    lineNumber: 307,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: `mt-4`,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$ui$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Skeleton"], {
                        shape: "rounded",
                        size: "lg",
                        width: "full",
                        className: "mt-4"
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                        lineNumber: 318,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                    lineNumber: 317,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: `transition-all duration-500 ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"}`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                            htmlFor: "email",
                            className: `block text-sm font-medium mb-2 transition-colors duration-500 ${isDarkMode ? "text-gray-300" : "text-gray-700"}`,
                            children: "Email"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                            lineNumber: 328,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-800 z-10",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$515$2e$0_react$40$19$2e$1$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                        lineNumber: 338,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                    lineNumber: 337,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                    id: "email",
                                    type: "email",
                                    value: email,
                                    onChange: (e)=>setEmail(e.target.value),
                                    required: true,
                                    disabled: loginMutation.isPending,
                                    className: `pl-10 py-3 text-base transition-all duration-300 focus:border-[#fbbf24] focus:ring-[#fbbf24]/30 focus:ring-2 hover:border-[#fbbf24]/60 relative z-0 ${isDarkMode ? "bg-gray-700/80 border-gray-600/60 text-white placeholder-gray-400 focus:bg-gray-600/80" : "bg-white border-gray-300/60 text-gray-900 placeholder-gray-500 focus:bg-white"}`,
                                    shape: "boxy",
                                    placeholder: "Enter your email address",
                                    autoComplete: "username"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                    lineNumber: 340,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                            lineNumber: 336,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                    lineNumber: 323,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: `mt-4 transition-all duration-500 delay-100 ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"}`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                            htmlFor: "password",
                            className: `block text-sm font-medium mb-2 transition-colors duration-500 ${isDarkMode ? "text-gray-300" : "text-gray-700"}`,
                            children: "Password"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                            lineNumber: 363,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-800 z-10",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$515$2e$0_react$40$19$2e$1$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Lock$3e$__["Lock"], {
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                        lineNumber: 373,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                    lineNumber: 372,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                    id: "password",
                                    type: showPassword ? "text" : "password",
                                    value: password,
                                    onChange: (e)=>setPassword(e.target.value),
                                    onKeyDown: (e)=>{
                                        // Show hint when Caps Lock is active
                                        // getModifierState works across browsers
                                        const caps = e.getModifierState?.("CapsLock");
                                        if (typeof caps === "boolean") setIsCapsLockOn(caps);
                                    },
                                    onKeyUp: (e)=>{
                                        const caps = e.getModifierState?.("CapsLock");
                                        if (typeof caps === "boolean") setIsCapsLockOn(caps);
                                    },
                                    required: true,
                                    disabled: loginMutation.isPending,
                                    className: `pl-10 pr-10 py-3 text-base transition-all duration-300 focus:border-[#fbbf24] focus:ring-[#fbbf24]/30 focus:ring-2 hover:border-[#fbbf24]/60 relative z-0 ${isDarkMode ? "bg-gray-700/80 border-gray-600/60 text-white placeholder-gray-400 focus:bg-gray-600/80" : "bg-white border-gray-300/60 text-gray-900 placeholder-gray-500 focus:bg-white"}`,
                                    shape: "boxy",
                                    placeholder: "Enter your password",
                                    autoComplete: "current-password"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                    lineNumber: 375,
                                    columnNumber: 15
                                }, this),
                                isCapsLockOn && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: `absolute right-12 top-1/2 -translate-y-1/2 px-1.5 py-0.5 rounded border text-[10px] font-semibold select-none pointer-events-none ${isDarkMode ? "bg-amber-500/20 text-amber-200 border-amber-400/40" : "bg-amber-100 text-amber-700 border-amber-300"}`,
                                    "aria-live": "polite",
                                    children: "CAPS"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                    lineNumber: 406,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>setShowPassword(!showPassword),
                                    className: `absolute inset-y-0 right-0 flex items-center justify-center w-10 bg-transparent border-none outline-none focus:outline-none transition-colors duration-200 ${isDarkMode ? "text-gray-500 hover:text-[#fbbf24]" : "text-gray-400 hover:text-[#f59e0b]"}`,
                                    disabled: loginMutation.isPending,
                                    title: showPassword ? "Hide password" : "Show password",
                                    children: showPassword ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$515$2e$0_react$40$19$2e$1$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeOff$3e$__["EyeOff"], {
                                        className: "w-4 h-4"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                        lineNumber: 429,
                                        columnNumber: 19
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$515$2e$0_react$40$19$2e$1$2e$0$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__["Eye"], {
                                        className: "w-4 h-4"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                        lineNumber: 431,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                    lineNumber: 417,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                            lineNumber: 371,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center mt-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    id: "remember-me",
                                    type: "checkbox",
                                    checked: rememberMe,
                                    onChange: (e)=>setRememberMe(e.target.checked),
                                    className: `w-4 h-4 rounded border-2 transition-all duration-200 focus:ring-2 focus:ring-[#fbbf24]/30 ${isDarkMode ? "bg-gray-700 border-gray-600 text-[#fbbf24] focus:bg-gray-600" : "bg-gray-50 border-gray-300 text-[#f59e0b] focus:bg-white"}`
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                    lineNumber: 437,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    htmlFor: "remember-me",
                                    className: `ml-3 text-sm cursor-pointer transition-colors duration-300 ${isDarkMode ? "text-gray-400 hover:text-gray-300" : "text-gray-600 hover:text-gray-700"}`,
                                    children: "Keep me signed in for 30 days"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                    lineNumber: 448,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                            lineNumber: 436,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                    lineNumber: 358,
                    columnNumber: 11
                }, this),
                loginMutation.error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: `
                rounded-md p-4 mt-4 
                transition-colors duration-200
                ${isDarkMode ? "bg-red-900/10 border border-red-500/20" : "bg-red-50 border border-red-200"}
                flex items-center gap-3
              `,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: `w-5 h-5 ${isDarkMode ? "text-red-400" : "text-red-500"}`,
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                lineNumber: 482,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                            lineNumber: 474,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `text-sm font-medium ${isDarkMode ? "text-red-400" : "text-red-700"}`,
                            children: getErrorMessage()
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                            lineNumber: 489,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                    lineNumber: 462,
                    columnNumber: 13
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: `transition-all duration-500 delay-200 ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"}`,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        type: "button",
                        disabled: loginMutation.isPending,
                        onClick: handleSubmit,
                        className: `w-full mt-3 text-base h-12 text-white border-0 shadow-lg transition-all duration-300 font-semibold tracking-wide disabled:opacity-70 disabled:cursor-not-allowed hover:scale-[1.02] active:scale-[0.98] ${loginSuccess ? "bg-gradient-to-r from-green-500 to-green-600" : "bg-gradient-to-r from-[#fbbf24] to-[#f59e0b] hover:from-[#f59e0b] hover:to-[#d97706]"}`,
                        children: loginMutation.isPending ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-center gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                    lineNumber: 516,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "font-medium",
                                    children: "Signing you in..."
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                    lineNumber: 517,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                            lineNumber: 515,
                            columnNumber: 17
                        }, this) : loginSuccess ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "flex items-center justify-center gap-2 font-semibold",
                            children: "Success! Redirecting..."
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                            lineNumber: 520,
                            columnNumber: 17
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "flex items-center justify-center gap-2 font-semibold",
                            children: [
                                "Sign in",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "w-4 h-4",
                                    fill: "none",
                                    stroke: "currentColor",
                                    viewBox: "0 0 24 24",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: 2,
                                        d: "M13 7l5 5m0 0l-5 5m5-5H6"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                        lineNumber: 532,
                                        columnNumber: 21
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                                    lineNumber: 526,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                            lineNumber: 524,
                            columnNumber: 17
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                        lineNumber: 504,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
                    lineNumber: 499,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true)
    }, void 0, false, {
        fileName: "[project]/apps/web/src/components/features/auth/LoginForm.tsx",
        lineNumber: 294,
        columnNumber: 5
    }, this);
}
_s(LoginForm, "95THMapiKs2S/z/AsHNzACfXDWs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$store$2f$useAuthStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$auth$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePostAuthLogin"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$shared$2f$src$2f$generated$2f$endpoints$2f$users$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetUsersMe"]
    ];
});
_c = LoginForm;
var _c;
__turbopack_context__.k.register(_c, "LoginForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/apps/web/src/app/(auth)/login/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>LoginPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.3_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$styled$2d$jsx$40$5$2e$1$2e$6_$40$babel$2b$core$40$7$2e$28$2e$5_react$40$19$2e$1$2e$0$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/styled-jsx@5.1.6_@babel+core@7.28.5_react@19.1.0/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$features$2f$auth$2f$LoginForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/components/features/auth/LoginForm.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$store$2f$useAuthStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/store/useAuthStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.3_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.3_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.3_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
// Custom hook for theme detection that integrates with the app's theme system
function useLoginTheme() {
    _s();
    const [isDarkMode, setIsDarkMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useLoginTheme.useEffect": ()=>{
            // Function to determine theme using the app's theme system
            const getTheme = {
                "useLoginTheme.useEffect.getTheme": ()=>{
                    // Check for saved theme preference in localStorage using the app's key
                    const savedTheme = localStorage.getItem("vantage-theme");
                    // Check system preference
                    const systemPrefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
                    const systemPrefersLight = window.matchMedia("(prefers-color-scheme: light)").matches;
                    // Priority: saved theme > system preference > default to light
                    if (savedTheme === "dark") return true;
                    if (savedTheme === "light") return false;
                    if (savedTheme === "system") {
                        return systemPrefersDark;
                    }
                    // If no saved theme, check system preference
                    if (systemPrefersLight) return false;
                    if (systemPrefersDark) return true;
                    // Default to light mode if no preference is set
                    return false;
                }
            }["useLoginTheme.useEffect.getTheme"];
            // Set initial theme
            setIsDarkMode(getTheme());
            // Listen for system preference changes
            const darkMediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
            const lightMediaQuery = window.matchMedia("(prefers-color-scheme: light)");
            const handleDarkChange = {
                "useLoginTheme.useEffect.handleDarkChange": (e)=>{
                    const savedTheme = localStorage.getItem("vantage-theme");
                    if (e.matches && (savedTheme === "system" || !savedTheme)) {
                        setIsDarkMode(true);
                    }
                }
            }["useLoginTheme.useEffect.handleDarkChange"];
            const handleLightChange = {
                "useLoginTheme.useEffect.handleLightChange": (e)=>{
                    const savedTheme = localStorage.getItem("vantage-theme");
                    if (e.matches && (savedTheme === "system" || !savedTheme)) {
                        setIsDarkMode(false);
                    }
                }
            }["useLoginTheme.useEffect.handleLightChange"];
            // Listen for storage changes (if user changes theme in another tab)
            const handleStorageChange = {
                "useLoginTheme.useEffect.handleStorageChange": (e)=>{
                    if (e.key === "vantage-theme") {
                        const newTheme = e.newValue;
                        if (newTheme === "dark") {
                            setIsDarkMode(true);
                        } else if (newTheme === "light") {
                            setIsDarkMode(false);
                        } else if (newTheme === "system") {
                            setIsDarkMode(window.matchMedia("(prefers-color-scheme: dark)").matches);
                        }
                    }
                }
            }["useLoginTheme.useEffect.handleStorageChange"];
            darkMediaQuery.addEventListener("change", handleDarkChange);
            lightMediaQuery.addEventListener("change", handleLightChange);
            window.addEventListener("storage", handleStorageChange);
            return ({
                "useLoginTheme.useEffect": ()=>{
                    darkMediaQuery.removeEventListener("change", handleDarkChange);
                    lightMediaQuery.removeEventListener("change", handleLightChange);
                    window.removeEventListener("storage", handleStorageChange);
                }
            })["useLoginTheme.useEffect"];
        }
    }["useLoginTheme.useEffect"], []);
    return isDarkMode;
}
_s(useLoginTheme, "bUs4CHDjU8AH+ZZYt8wlh4bHppI=");
function LoginPage() {
    _s1();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { isAuthenticated, user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$store$2f$useAuthStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"])();
    const isDarkMode = useLoginTheme();
    // Redirect authenticated users to appropriate dashboard
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LoginPage.useEffect": ()=>{
            if (isAuthenticated && user) {
                const isAdmin = user.role === "MLGOO_DILG";
                const isAssessor = user.role === "ASSESSOR";
                const isValidator = user.role === "VALIDATOR";
                let dashboardPath;
                if (isAdmin) {
                    dashboardPath = "/mlgoo/dashboard";
                } else if (isAssessor) {
                    dashboardPath = "/assessor/submissions";
                } else if (isValidator) {
                    dashboardPath = "/validator/submissions";
                } else {
                    dashboardPath = "/blgu/dashboard";
                }
                router.replace(dashboardPath);
            }
        }
    }["LoginPage.useEffect"], [
        isAuthenticated,
        user,
        router
    ]);
    // Show loading or redirect if user is authenticated
    if (isAuthenticated) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `relative h-screen flex items-center justify-center transition-colors duration-500 ${isDarkMode ? "bg-gradient-to-br from-slate-800 via-gray-900 to-black" : "bg-gradient-to-br from-slate-50 via-yellow-50 to-amber-50"}`,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded-full h-6 w-6 border-2 border-[#fbbf24] border-t-transparent mx-auto mb-4 animate-spin"
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                        lineNumber: 134,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: `transition-colors duration-500 ${isDarkMode ? "text-gray-300" : "text-gray-600"}`,
                        children: "Redirecting to dashboard..."
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                        lineNumber: 135,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                lineNumber: 133,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
            lineNumber: 126,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "jsx-3d549892c4166a58" + " " + `relative min-h-screen flex flex-col transition-colors duration-500 ${isDarkMode ? "bg-gradient-to-br from-slate-800 via-gray-900 to-black" : "bg-gradient-to-br from-slate-50 via-yellow-50 to-amber-50"}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-3d549892c4166a58" + " " + "absolute inset-0 overflow-hidden pointer-events-none z-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-3d549892c4166a58" + " " + "absolute inset-0 opacity-[0.03]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    backgroundImage: `
              linear-gradient(rgba(251, 191, 36, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(251, 191, 36, 0.1) 1px, transparent 1px)
            `,
                                    backgroundSize: "50px 50px"
                                },
                                className: "jsx-3d549892c4166a58" + " " + "absolute inset-0"
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                lineNumber: 159,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-3d549892c4166a58" + " " + "absolute top-1/4 left-1/4 w-32 h-32 border border-[#fbbf24] rounded-full"
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                lineNumber: 170,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-3d549892c4166a58" + " " + "absolute bottom-1/3 right-1/3 w-24 h-24 border border-[#f59e0b] rounded-full"
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                lineNumber: 171,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-3d549892c4166a58" + " " + "absolute top-1/2 right-1/4 w-16 h-16 border border-[#d97706] rounded-full"
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                lineNumber: 172,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    animationDelay: "0.5s"
                                },
                                className: "jsx-3d549892c4166a58" + " " + "absolute top-1/6 right-1/6 w-20 h-20 border border-[#fbbf24] transform rotate-45"
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                lineNumber: 173,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    animationDelay: "1.5s"
                                },
                                className: "jsx-3d549892c4166a58" + " " + "absolute bottom-1/4 left-1/6 w-28 h-28 border border-[#f59e0b] transform rotate-12"
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                lineNumber: 177,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                        lineNumber: 157,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-3d549892c4166a58" + " " + `absolute -top-40 -right-40 w-48 h-48 lg:w-60 lg:h-60 xl:w-80 xl:h-80 rounded-full filter blur-xl transition-all duration-500 ${isDarkMode ? "bg-[#fbbf24]/60 mix-blend-screen" : "bg-[#fbbf24]/30 mix-blend-multiply"}`
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                        lineNumber: 185,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-3d549892c4166a58" + " " + `absolute -top-20 -right-20 w-32 h-32 lg:w-40 lg:h-40 xl:w-48 xl:h-48 rounded-full filter blur-lg transition-all duration-500 ${isDarkMode ? "bg-[#fbbf24]/40 mix-blend-screen" : "bg-[#fbbf24]/20 mix-blend-multiply"}`
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                        lineNumber: 192,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-3d549892c4166a58" + " " + `absolute -bottom-40 -left-40 w-48 h-48 lg:w-60 lg:h-60 xl:w-80 xl:h-80 rounded-full filter blur-xl transition-all duration-500 ${isDarkMode ? "bg-[#f59e0b]/60 mix-blend-screen" : "bg-[#f59e0b]/30 mix-blend-multiply"}`
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                        lineNumber: 201,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-3d549892c4166a58" + " " + `absolute -bottom-20 -left-20 w-32 h-32 lg:w-40 lg:h-40 xl:w-48 xl:h-48 rounded-full filter blur-lg transition-all duration-500 ${isDarkMode ? "bg-[#f59e0b]/40 mix-blend-screen" : "bg-[#f59e0b]/20 mix-blend-multiply"}`
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                        lineNumber: 208,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-3d549892c4166a58" + " " + `absolute top-40 left-40 w-48 h-48 lg:w-60 lg:h-60 xl:w-80 xl:h-80 rounded-full filter blur-xl transition-all duration-500 ${isDarkMode ? "bg-[#d97706]/50 mix-blend-screen" : "bg-[#d97706]/25 mix-blend-multiply"}`
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                        lineNumber: 217,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-3d549892c4166a58" + " " + `absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full filter blur-3xl transition-all duration-500 ${isDarkMode ? "bg-[#fbbf24]/10 mix-blend-screen" : "bg-[#fbbf24]/5 mix-blend-multiply"}`
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                        lineNumber: 226,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                lineNumber: 155,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-3d549892c4166a58" + " " + "relative z-10 w-full max-w-6xl mx-auto flex items-center justify-center gap-x-24 flex-1 py-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-3d549892c4166a58" + " " + "hidden lg:flex flex-col items-center justify-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-3d549892c4166a58" + " " + "relative z-10 flex flex-col items-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-3d549892c4166a58" + " " + "mb-6",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-3d549892c4166a58" + " " + "relative",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "jsx-3d549892c4166a58" + " " + "flex items-center justify-center p-0",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                src: "/officialLogo/VANTAGE.webp",
                                                alt: "VANTAGE official logo",
                                                width: 240,
                                                height: 240,
                                                sizes: "180px",
                                                priority: true,
                                                className: "w-[180px] h-[180px] object-contain"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                                lineNumber: 244,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                            lineNumber: 243,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                        lineNumber: 241,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                    lineNumber: 240,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "jsx-3d549892c4166a58" + " " + `text-4xl font-extrabold mb-4 tracking-tight text-center ${isDarkMode ? "text-white" : "text-gray-900"}`,
                                    children: "VANTAGE"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                    lineNumber: 256,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "jsx-3d549892c4166a58" + " " + `text-base font-medium text-center max-w-md mb-8 leading-relaxed ${isDarkMode ? "text-gray-300" : "text-gray-600"}`,
                                    children: "Validating Assessments and Nurturing Transparency for Advantaged Governance and Evaluation"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                    lineNumber: 263,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                            lineNumber: 239,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                        lineNumber: 237,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-3d549892c4166a58" + " " + "flex flex-col items-center justify-center min-w-[380px] max-w-md w-full px-4 py-2 sm:px-6 lg:px-0",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                boxShadow: isDarkMode ? "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 20px 25px -5px rgba(0, 0, 0, 0.4), 0 40px 60px -12px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(251, 191, 36, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.08), inset 0 0 20px rgba(251, 191, 36, 0.03)" : "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 20px 25px -5px rgba(0, 0, 0, 0.3), 0 40px 60px -12px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(251, 191, 36, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.15), inset 0 0 20px rgba(251, 191, 36, 0.02)"
                            },
                            className: "jsx-3d549892c4166a58" + " " + `w-full backdrop-blur-md rounded-2xl p-8 md:p-8 flex flex-col space-y-5 ${isDarkMode ? "bg-gray-800/95 border border-gray-700/40" : "bg-white/95 border border-white/50"}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-3d549892c4166a58" + " " + "text-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "jsx-3d549892c4166a58" + " " + `text-2xl md:text-3xl font-extrabold mb-2 leading-tight tracking-tight transition-colors duration-500 ${isDarkMode ? "text-white" : "text-gray-900"}`,
                                            children: "Welcome, Partner in Governance"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                            lineNumber: 289,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "jsx-3d549892c4166a58" + " " + `text-base leading-relaxed transition-colors duration-500 ${isDarkMode ? "text-gray-300" : "text-gray-600"}`,
                                            children: "Sign in to the VANTAGE Platform."
                                        }, void 0, false, {
                                            fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                            lineNumber: 296,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                    lineNumber: 288,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-3d549892c4166a58" + " " + "flex-1 flex flex-col justify-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$features$2f$auth$2f$LoginForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        isDarkMode: isDarkMode
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                        lineNumber: 305,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                    lineNumber: 304,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "jsx-3d549892c4166a58" + " " + `text-sm text-center mt-4 ${isDarkMode ? "text-gray-400" : "text-gray-500"}`,
                                    children: "For account assistance, please contact your MLGRC Administrator."
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                    lineNumber: 307,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                            lineNumber: 276,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                        lineNumber: 274,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                lineNumber: 235,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
                className: "jsx-3d549892c4166a58" + " " + `relative z-20 w-full backdrop-blur-md py-3 px-4 transition-colors duration-500 ${isDarkMode ? "bg-black/50 border-t border-white/10" : "bg-white/90 border-t border-gray-200/80"}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "jsx-3d549892c4166a58" + " " + "max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-3d549892c4166a58" + " " + `flex items-center gap-3 text-xs ${isDarkMode ? "text-gray-400" : "text-gray-500"}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "jsx-3d549892c4166a58",
                                    children: "© 2024 MLGRC Davao del Sur"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                    lineNumber: 331,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "jsx-3d549892c4166a58" + " " + "hidden md:inline",
                                    children: "|"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                    lineNumber: 332,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "jsx-3d549892c4166a58" + " " + "flex items-center gap-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            className: "jsx-3d549892c4166a58" + " " + "w-3 h-3",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.031 9-11.622 0-1.042-.133-2.052-.382-3.016z",
                                                className: "jsx-3d549892c4166a58"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                                lineNumber: 340,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                            lineNumber: 334,
                                            columnNumber: 15
                                        }, this),
                                        "Secured Platform"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                    lineNumber: 333,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                            lineNumber: 326,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-3d549892c4166a58" + " " + `text-center text-xs ${isDarkMode ? "text-gray-400" : "text-gray-500"}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-3d549892c4166a58",
                                    children: "Support: (02) 1234-5678 | support.vantage@mlgrc.gov.ph"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                    lineNumber: 355,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-3d549892c4166a58" + " " + "text-xs opacity-75",
                                    children: "Version 1.0.0 | Build 2024.01.15"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                                    lineNumber: 356,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                            lineNumber: 350,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                    lineNumber: 325,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
                lineNumber: 318,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$styled$2d$jsx$40$5$2e$1$2e$6_$40$babel$2b$core$40$7$2e$28$2e$5_react$40$19$2e$1$2e$0$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "3d549892c4166a58",
                children: "@keyframes float{0%{transform:translateY(0)}50%{transform:translateY(-16px)}to{transform:translateY(0)}}.animate-float{animation:3s ease-in-out infinite float}@keyframes fade-in-blob{0%{opacity:0}to{opacity:.6}}.animate-fade-in-blob{animation:1.2s ease-in forwards fade-in-blob}.animate-fade-in-blob-light{animation:1.2s ease-in .5s forwards fade-in-blob}.animate-blob{animation:8s linear infinite alternate blob}@keyframes blob{0%{transform:scale(1)translate(0)}33%{transform:scale(1.1,.9)translate(30px,-20px)}66%{transform:scale(.9,1.1)translate(-20px,30px)}to{transform:scale(1)translate(0)}}.animation-delay-800{animation-delay:.8s}.animation-delay-2000{animation-delay:2s}.animation-delay-4000{animation-delay:4s}.shadow-3xl{box-shadow:0 35px 60px -12px #00000040,0 0 0 1px #ffffff0d}"
            }, void 0, false, void 0, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/web/src/app/(auth)/login/page.tsx",
        lineNumber: 147,
        columnNumber: 5
    }, this);
}
_s1(LoginPage, "ja5jKY8xi2rFmzvJOl9dh6fDnpY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$store$2f$useAuthStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"],
        useLoginTheme
    ];
});
_c = LoginPage;
var _c;
__turbopack_context__.k.register(_c, "LoginPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=_6a6d62c2._.js.map